from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parent.parent
DATA_ROOT = PROJECT_ROOT / "data"
LOG_ROOT = PROJECT_ROOT / "logs"
FAILED_ROOT = PROJECT_ROOT / "data_fetcher" / "data" / "failed"


@dataclass(frozen=True)
class BoardPathConfig:
    board_type: str
    raw_dir: Path
    normalized_dir: Path


BOARD_PATHS = {
    "industry": BoardPathConfig(
        board_type="industry",
        raw_dir=DATA_ROOT / "raw" / "industry_daily",
        normalized_dir=DATA_ROOT / "normalized" / "industry_daily",
    ),
    "concept": BoardPathConfig(
        board_type="concept",
        raw_dir=DATA_ROOT / "raw" / "concept_daily",
        normalized_dir=DATA_ROOT / "normalized" / "concept_daily",
    ),
}

DEFAULT_START = "20200101"
LOG_FILE = LOG_ROOT / "fetch_akshare_boards.log"
SOURCE_NAME = "akshare_eastmoney_board"
RETRY_DELAYS = (10, 30, 60, 120, 300)
