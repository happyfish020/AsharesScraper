# Data Fetcher / Local Industry Proxy

这个目录包含独立的数据任务模块，不包含任何策略、选股、回测或交易逻辑。

## 安装依赖

```bash
pip install -r requirements.txt
pip install akshare --upgrade
```

## 一、AkShare 板块采集器

常用命令：

```bash
python data_fetcher/fetch_akshare_boards.py --type industry
python data_fetcher/fetch_akshare_boards.py --type industry --board-name 光学光电子
python data_fetcher/fetch_akshare_boards.py --type industry --resume-failed
```

输出目录：

- `data/raw/industry_daily/*.csv`
- `data/raw/concept_daily/*.csv`
- `data/normalized/industry_daily/*.csv`
- `data/normalized/concept_daily/*.csv`
- `logs/fetch_akshare_boards.log`
- `data_fetcher/data/failed/industry_failed.csv`
- `data_fetcher/data/failed/concept_failed.csv`

## 二、本地行业映射表 + 自建行业代理指数

这个构建器不依赖东方财富板块接口，直接使用本地数据库中的：

- `cn_stock_daily_price`
- `cn_board_member_map_d`
- `cn_board_industry_master`

默认口径：

- 行业层级：`SW L1`
- 行业主数据来源：`TUSHARE_SW2021_L1`
- 日级成员事实来源：`cn_board_member_map_d`

### 生成对象

- `cn_local_industry_map_hist`
- `cn_local_industry_proxy_daily`
- `cn_local_task_status`
- `logs/local_industry_proxy.log`

### 映射保护规则

- 任一日期同一 `symbol` 只能归属一个 `SW L1`
- `valid_from <= valid_to`
- `industry_id` 不允许为空
- `valid_to` 统一按下一条 `valid_from - 1 day` 推导
- 最后一条 `valid_to = 9999-12-31`

### 运行命令

刷新本地映射：

```bash
python data_fetcher/build_local_industry_proxy.py --mode refresh-map
```

校验映射唯一性：

```bash
python data_fetcher/build_local_industry_proxy.py --mode validate-map
```

日常日更：

```bash
python data_fetcher/build_local_industry_proxy.py --mode daily
```

每周刷新：

```bash
python data_fetcher/build_local_industry_proxy.py --mode weekly
```

指定区间补刷：

```bash
python data_fetcher/build_local_industry_proxy.py --mode backfill --start 20260401 --end 20260429
```

做覆盖审计：

```bash
python data_fetcher/build_local_industry_proxy.py --mode audit
```

串行执行一轮：

```bash
python data_fetcher/build_local_industry_proxy.py --mode all
```

### 运行模式说明

- `refresh-map`
  - 从 `cn_board_member_map_d` 过滤 SW L1 行业，压缩成历史映射窗口
- `validate-map`
  - 校验唯一归属、空行业、非法日期区间、重叠窗口
- `daily`
  - 从代理表最新日期之后开始增量刷新
- `weekly`
  - 先刷新映射，再重建最近 `35` 天，并补缺失日期
- `backfill`
  - 按指定日期区间重建代理指数
- `audit`
  - 检查日期缺口、行业覆盖缺口、低覆盖率行
- `all`
  - 依次执行 `refresh-map -> validate-map -> daily -> audit`

### 代理表字段

`cn_local_industry_proxy_daily` 包含：

- `trade_date`
- `industry_id`
- `industry_name`
- `industry_level`
- `member_count`
- `total_member_count`
- `coverage_ratio`
- `ret_eqw`
- `ret_amt_w`
- `amount_sum`
- `up_count`
- `down_count`
- `up_ratio`
- `rs20_eqw`
- `rs20_amt_w`
- `rs60_eqw`
- `rs60_amt_w`
- `proxy_close_eqw`
- `proxy_close_amt_w`
- `source`
- `updated_at`

字段说明：

- `member_count`
  - 当天实际参与计算的股票数量
- `total_member_count`
  - 当天行业总成员数
- `coverage_ratio`
  - `member_count / total_member_count`
- `ret_eqw`
  - 等权收益
- `ret_amt_w`
  - 成交额加权收益
- `up_ratio`
  - `up_count / member_count`
- `rs20_* / rs60_*`
  - 代理指数 20 日 / 60 日相对强度

### 无行情处理规则

- 当天缺少 `close`
- 或缺少可用收益字段 `pre_close / chg_pct`
- 或缺少 `amount`

则该股票不参与当日收益聚合。

因此：

- `member_count` 是实际参与数
- `coverage_ratio < 0.6` 的行业应视为低质量样本

### 日常调度建议

- 每日股票日线入库后执行：

```bash
python data_fetcher/build_local_industry_proxy.py --mode daily
```

- 每周执行：

```bash
python data_fetcher/build_local_industry_proxy.py --mode weekly
```

- 如果怀疑历史断档：

```bash
python data_fetcher/build_local_industry_proxy.py --mode audit
python data_fetcher/build_local_industry_proxy.py --mode backfill --start 20260401 --end 20260429
```
