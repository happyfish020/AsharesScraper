# AkShare 板块日线采集器

这是一个独立的数据拉取模块，只负责 A 股行业板块和概念板块的日线采集、标准化、落盘、日志与失败恢复，不包含任何策略、选股、回测或交易逻辑。

## 安装依赖

```bash
pip install -r requirements.txt
pip install akshare --upgrade
```

## 运行命令

```bash
python data_fetcher/fetch_akshare_boards.py --type industry
python data_fetcher/fetch_akshare_boards.py --type concept
python data_fetcher/fetch_akshare_boards.py --type all
python data_fetcher/fetch_akshare_boards.py --type industry --start 20230101 --end 20240630
python data_fetcher/fetch_akshare_boards.py --type industry --board-name 光学光电子
python data_fetcher/fetch_akshare_boards.py --type industry --limit 5
python data_fetcher/fetch_akshare_boards.py --type industry --resume-failed
python data_fetcher/fetch_akshare_boards.py --type all --force-refresh
```

## 参数说明

- `--type`: `industry` / `concept` / `all`
- `--start`: 起始日期，格式 `YYYYMMDD`，默认 `20200101`
- `--end`: 结束日期，格式 `YYYYMMDD`，默认当天
- `--force-refresh`: 忽略本地缓存，重新全量拉取
- `--resume-failed`: 只重跑失败清单里的板块
- `--limit N`: 只拉前 N 个板块，便于测试
- `--board-name 名称`: 只拉单个板块
- `--sleep-min 3`: 单板块成功后的最小休眠秒数
- `--sleep-max 8`: 单板块成功后的最大休眠秒数
- `--batch-cooldown-every 10`: 每成功 N 个板块后触发额外冷却
- `--batch-cooldown-min 30`: 批量冷却最小秒数
- `--batch-cooldown-max 90`: 批量冷却最大秒数

## 输出目录

- `data/raw/industry_daily/*.csv`
- `data/raw/concept_daily/*.csv`
- `data/normalized/industry_daily/*.csv`
- `data/normalized/concept_daily/*.csv`
- `logs/fetch_akshare_boards.log`
- `data_fetcher/data/failed/industry_failed.csv`
- `data_fetcher/data/failed/concept_failed.csv`

## 增量与恢复规则

1. 本地文件不存在时，全量拉取指定日期区间。
2. 本地标准化文件存在时，自动读取最大 `trade_date`，只追加之后的新数据。
3. 合并后按 `trade_date` 去重，并按升序保存。
4. 已成功保存且没有新日期的板块，下次默认跳过。
5. 单个板块失败会写入失败清单，不影响其他板块继续执行。
6. 连续失败达到 5 个板块时，任务会主动停止，避免继续高频打接口。
7. 停止后可等待一段时间，再使用 `--resume-failed` 恢复。

## 标准化字段

- `board_type`
- `board_name`
- `trade_date`
- `open`
- `close`
- `high`
- `low`
- `volume`
- `amount`
- `pct_change`
- `source`
- `update_time`

`trade_date` 统一为 `YYYY-MM-DD`。

## 限流保护

- 默认低频串行执行，不做高频连续请求。
- 每个成功板块后随机休眠 `3-8` 秒。
- 每成功 10 个板块后额外随机休眠 `30-90` 秒。
- 网络异常重试 5 次，采用指数退避：`10s / 30s / 60s / 120s / 300s`。

## 排障建议

- 先执行 `pip install akshare --upgrade`
- 先单独测试 `--board-name 光学光电子`
- 如果仍然出现 `RemoteDisconnected`，继续降低频率
- 等待 `10-30` 分钟后再执行 `--resume-failed`
- 不要一次性高速扫全量行业或概念板块
