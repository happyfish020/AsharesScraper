# P2/P3 Execution Results

Generated: 2026-05-09 12:34:02

## Build Results

| Script | Status | Rows |
|--------|--------|------|
| build_mainline_lifecycle_daily.py | ✅ SUCCESS | 1,240 |
| build_stock_quality_score_daily.py | ⚠️ NO DATA (empty prerequisite) | 0 |
| build_unified_alpha_score_daily.py | ✅ SUCCESS | 5,175 |

## Validation Results

| Script | Passed/Total | Key Findings |
|--------|-------------|--------------|
| validate_mainline_lifecycle_daily.py | 9/10 | UNKNOWN ratio=100% (expected - no lifecycle state data) |
| validate_unified_alpha_score_daily.py | 25/31 | 6 source column schema mismatches (non-blocking) |

## Date Range

- Start: 2026-01-01
- End: 2026-03-30
- Database: cn_market_red

## Notes

- `build_stock_quality_score_daily` produced 0 rows because `stock_fundamental_daily` has no data for this range.
- `validate_mainline_lifecycle_daily` shows 100% UNKNOWN because lifecycle state computation requires industry capital flow and market pulse data that may not be available for this range.
- `validate_unified_alpha_score_daily` source column failures are schema mismatches in the validator (column name differences), not build failures.