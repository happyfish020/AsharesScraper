# Mainline Lifecycle Summary

**Date Range:** 20260101 ~ 20260330

**Generated:** 2026-05-09 11:34:36

**Total Rows:** 1240

---

## 2026-01-26

- Total Mainlines: 31
- State Distribution: {'UNKNOWN': 31}
- Top TREND_EXPANSION: N/A
- Top TOP_DECAY: N/A
- Risk-Off Flag: NO
- Rows Written: 31

---

## 2026-01-27

- Total Mainlines: 31
- State Distribution: {'UNKNOWN': 31}
- Top TREND_EXPANSION: N/A
- Top TOP_DECAY: N/A
- Risk-Off Flag: NO
- Rows Written: 31

---

## 2026-01-28

- Total Mainlines: 31
- State Distribution: {'UNKNOWN': 31}
- Top TREND_EXPANSION: N/A
- Top TOP_DECAY: N/A
- Risk-Off Flag: NO
- Rows Written: 31

---

## 2026-01-29

- Total Mainlines: 31
- State Distribution: {'UNKNOWN': 31}
- Top TREND_EXPANSION: N/A
- Top TOP_DECAY: N/A
- Risk-Off Flag: NO
- Rows Written: 31

---

## 2026-01-30

- Total Mainlines: 31
- State Distribution: {'UNKNOWN': 31}
- Top TREND_EXPANSION: N/A
- Top TOP_DECAY: N/A
- Risk-Off Flag: NO
- Rows Written: 31

---

## 2026-02-02

- Total Mainlines: 31
- State Distribution: {'UNKNOWN': 31}
- Top TREND_EXPANSION: N/A
- Top TOP_DECAY: N/A
- Risk-Off Flag: NO
- Rows Written: 31

---

## 2026-02-03

- Total Mainlines: 31
- State Distribution: {'UNKNOWN': 31}
- Top TREND_EXPANSION: N/A
- Top TOP_DECAY: N/A
- Risk-Off Flag: NO
- Rows Written: 31

---

## 2026-02-04

- Total Mainlines: 31
- State Distribution: {'UNKNOWN': 31}
- Top TREND_EXPANSION: N/A
- Top TOP_DECAY: N/A
- Risk-Off Flag: NO
- Rows Written: 31

---

## 2026-02-05

- Total Mainlines: 31
- State Distribution: {'UNKNOWN': 31}
- Top TREND_EXPANSION: N/A
- Top TOP_DECAY: N/A
- Risk-Off Flag: NO
- Rows Written: 31

---

## 2026-02-06

- Total Mainlines: 31
- State Distribution: {'UNKNOWN': 31}
- Top TREND_EXPANSION: N/A
- Top TOP_DECAY: N/A
- Risk-Off Flag: NO
- Rows Written: 31

---

## 2026-02-09

- Total Mainlines: 31
- State Distribution: {'UNKNOWN': 31}
- Top TREND_EXPANSION: N/A
- Top TOP_DECAY: N/A
- Risk-Off Flag: NO
- Rows Written: 31

---

## 2026-02-10

- Total Mainlines: 31
- State Distribution: {'UNKNOWN': 31}
- Top TREND_EXPANSION: N/A
- Top TOP_DECAY: N/A
- Risk-Off Flag: NO
- Rows Written: 31

---

## 2026-02-11

- Total Mainlines: 31
- State Distribution: {'UNKNOWN': 31}
- Top TREND_EXPANSION: N/A
- Top TOP_DECAY: N/A
- Risk-Off Flag: NO
- Rows Written: 31

---

## 2026-02-12

- Total Mainlines: 31
- State Distribution: {'UNKNOWN': 31}
- Top TREND_EXPANSION: N/A
- Top TOP_DECAY: N/A
- Risk-Off Flag: NO
- Rows Written: 31

---

## 2026-02-13

- Total Mainlines: 31
- State Distribution: {'UNKNOWN': 31}
- Top TREND_EXPANSION: N/A
- Top TOP_DECAY: N/A
- Risk-Off Flag: NO
- Rows Written: 31

---

## 2026-02-24

- Total Mainlines: 31
- State Distribution: {'UNKNOWN': 31}
- Top TREND_EXPANSION: N/A
- Top TOP_DECAY: N/A
- Risk-Off Flag: NO
- Rows Written: 31

---

## 2026-02-25

- Total Mainlines: 31
- State Distribution: {'UNKNOWN': 31}
- Top TREND_EXPANSION: N/A
- Top TOP_DECAY: N/A
- Risk-Off Flag: NO
- Rows Written: 31

---

## 2026-02-26

- Total Mainlines: 31
- State Distribution: {'UNKNOWN': 31}
- Top TREND_EXPANSION: N/A
- Top TOP_DECAY: N/A
- Risk-Off Flag: NO
- Rows Written: 31

---

## 2026-02-27

- Total Mainlines: 31
- State Distribution: {'UNKNOWN': 31}
- Top TREND_EXPANSION: N/A
- Top TOP_DECAY: N/A
- Risk-Off Flag: NO
- Rows Written: 31

---

## 2026-03-02

- Total Mainlines: 31
- State Distribution: {'UNKNOWN': 31}
- Top TREND_EXPANSION: N/A
- Top TOP_DECAY: N/A
- Risk-Off Flag: NO
- Rows Written: 31

---

## 2026-03-03

- Total Mainlines: 31
- State Distribution: {'UNKNOWN': 31}
- Top TREND_EXPANSION: N/A
- Top TOP_DECAY: N/A
- Risk-Off Flag: NO
- Rows Written: 31

---

## 2026-03-04

- Total Mainlines: 31
- State Distribution: {'UNKNOWN': 31}
- Top TREND_EXPANSION: N/A
- Top TOP_DECAY: N/A
- Risk-Off Flag: NO
- Rows Written: 31

---

## 2026-03-05

- Total Mainlines: 31
- State Distribution: {'UNKNOWN': 31}
- Top TREND_EXPANSION: N/A
- Top TOP_DECAY: N/A
- Risk-Off Flag: NO
- Rows Written: 31

---

## 2026-03-06

- Total Mainlines: 31
- State Distribution: {'UNKNOWN': 31}
- Top TREND_EXPANSION: N/A
- Top TOP_DECAY: N/A
- Risk-Off Flag: NO
- Rows Written: 31

---

## 2026-03-09

- Total Mainlines: 31
- State Distribution: {'UNKNOWN': 31}
- Top TREND_EXPANSION: N/A
- Top TOP_DECAY: N/A
- Risk-Off Flag: NO
- Rows Written: 31

---

## 2026-03-10

- Total Mainlines: 31
- State Distribution: {'UNKNOWN': 31}
- Top TREND_EXPANSION: N/A
- Top TOP_DECAY: N/A
- Risk-Off Flag: NO
- Rows Written: 31

---

## 2026-03-11

- Total Mainlines: 31
- State Distribution: {'UNKNOWN': 31}
- Top TREND_EXPANSION: N/A
- Top TOP_DECAY: N/A
- Risk-Off Flag: NO
- Rows Written: 31

---

## 2026-03-12

- Total Mainlines: 31
- State Distribution: {'UNKNOWN': 31}
- Top TREND_EXPANSION: N/A
- Top TOP_DECAY: N/A
- Risk-Off Flag: NO
- Rows Written: 31

---

## 2026-03-13

- Total Mainlines: 31
- State Distribution: {'UNKNOWN': 31}
- Top TREND_EXPANSION: N/A
- Top TOP_DECAY: N/A
- Risk-Off Flag: NO
- Rows Written: 31

---

## 2026-03-16

- Total Mainlines: 31
- State Distribution: {'UNKNOWN': 31}
- Top TREND_EXPANSION: N/A
- Top TOP_DECAY: N/A
- Risk-Off Flag: NO
- Rows Written: 31

---

## 2026-03-17

- Total Mainlines: 31
- State Distribution: {'UNKNOWN': 31}
- Top TREND_EXPANSION: N/A
- Top TOP_DECAY: N/A
- Risk-Off Flag: NO
- Rows Written: 31

---

## 2026-03-18

- Total Mainlines: 31
- State Distribution: {'UNKNOWN': 31}
- Top TREND_EXPANSION: N/A
- Top TOP_DECAY: N/A
- Risk-Off Flag: NO
- Rows Written: 31

---

## 2026-03-19

- Total Mainlines: 31
- State Distribution: {'UNKNOWN': 31}
- Top TREND_EXPANSION: N/A
- Top TOP_DECAY: N/A
- Risk-Off Flag: NO
- Rows Written: 31

---

## 2026-03-20

- Total Mainlines: 31
- State Distribution: {'UNKNOWN': 31}
- Top TREND_EXPANSION: N/A
- Top TOP_DECAY: N/A
- Risk-Off Flag: NO
- Rows Written: 31

---

## 2026-03-23

- Total Mainlines: 31
- State Distribution: {'UNKNOWN': 31}
- Top TREND_EXPANSION: N/A
- Top TOP_DECAY: N/A
- Risk-Off Flag: NO
- Rows Written: 31

---

## 2026-03-24

- Total Mainlines: 31
- State Distribution: {'UNKNOWN': 31}
- Top TREND_EXPANSION: N/A
- Top TOP_DECAY: N/A
- Risk-Off Flag: NO
- Rows Written: 31

---

## 2026-03-25

- Total Mainlines: 31
- State Distribution: {'UNKNOWN': 31}
- Top TREND_EXPANSION: N/A
- Top TOP_DECAY: N/A
- Risk-Off Flag: NO
- Rows Written: 31

---

## 2026-03-26

- Total Mainlines: 31
- State Distribution: {'UNKNOWN': 31}
- Top TREND_EXPANSION: N/A
- Top TOP_DECAY: N/A
- Risk-Off Flag: NO
- Rows Written: 31

---

## 2026-03-27

- Total Mainlines: 31
- State Distribution: {'UNKNOWN': 31}
- Top TREND_EXPANSION: N/A
- Top TOP_DECAY: N/A
- Risk-Off Flag: NO
- Rows Written: 31

---

## 2026-03-30

- Total Mainlines: 31
- State Distribution: {'UNKNOWN': 31}
- Top TREND_EXPANSION: N/A
- Top TOP_DECAY: N/A
- Risk-Off Flag: NO
- Rows Written: 31

---

## Overall State Distribution

- **UNKNOWN**: 1240 (100.0%)

## Risk Flag Summary

- **DATA_INSUFFICIENT**: 1240

## Lifecycle State Definitions

### BOTTOM_REPAIR
主线从低位修复，突破比例和趋势一致性从低位改善。

### TREND_EXPANSION
主线进入主升阶段，资金、趋势、突破、新高、龙头密度共振。

### DIFFUSION
主线从少数龙头扩散到产业链更多环节，强股数量扩大。

### DIVERGENCE
主线仍强，但内部结构开始分歧，龙头拥挤或扩散失败。

### TOP_DECAY
主线热度衰退，突破比例、新高比例、rotation rank 恶化。

### RISK_OFF
市场整体风险收缩，主线评分失效或多数行业同步转弱。

### UNKNOWN
数据不足或无法判断。

