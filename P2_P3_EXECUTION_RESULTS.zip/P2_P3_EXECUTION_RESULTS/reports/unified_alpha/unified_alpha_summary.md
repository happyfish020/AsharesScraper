# Unified Alpha Score Report
**Date Range:** 2026-01-01 ~ 2026-03-30
**Generated:** 2026-05-09 12:32:31

## Summary Statistics

- Total rows: 5175
- Unique dates: 1
- Unique symbols: 5175
- Unique industries: 31

### Alpha Bucket Distribution

| Bucket | Count | Percentage |
|--------|-------|------------|
| TOP_1 | 156 | 3.01% |
| TOP_5 | 5002 | 96.66% |
| TOP_10 | 0 | 0.00% |
| TOP_20 | 0 | 0.00% |
| WATCH | 0 | 0.00% |
| NEUTRAL | 0 | 0.00% |
| AVOID | 17 | 0.33% |

### Top 20 by Final Score

| Rank | Trade Date | Symbol | Industry | Final Score | Bucket |
|------|------------|--------|----------|-------------|--------|
| 1 | 2026-02-27 | 000035 | 801970.SI | 0.5190 | TOP_1 |
| 2 | 2026-02-27 | 000039 |  | 0.5190 | TOP_1 |
| 3 | 2026-02-27 | 000157 |  | 0.5190 | TOP_1 |
| 4 | 2026-02-27 | 000333 |  | 0.5190 | TOP_1 |
| 5 | 2026-02-27 | 000338 |  | 0.5190 | TOP_1 |
| 6 | 2026-02-27 | 000423 | 801150.SI | 0.5190 | TOP_1 |
| 7 | 2026-02-27 | 000425 |  | 0.5190 | TOP_1 |
| 8 | 2026-02-27 | 000538 | 801150.SI | 0.5190 | TOP_1 |
| 9 | 2026-02-27 | 000559 |  | 0.5190 | TOP_1 |
| 10 | 2026-02-27 | 000568 | 801120.SI | 0.5190 | TOP_1 |
| 11 | 2026-02-27 | 000657 | 801050.SI | 0.5190 | TOP_1 |
| 12 | 2026-02-27 | 000683 | 801030.SI | 0.5190 | TOP_1 |
| 13 | 2026-02-27 | 000768 |  | 0.5190 | TOP_1 |
| 14 | 2026-02-27 | 000792 | 801030.SI | 0.5190 | TOP_1 |
| 15 | 2026-02-27 | 000833 | 801230.SI | 0.5190 | TOP_1 |
| 16 | 2026-02-27 | 000858 | 801120.SI | 0.5190 | TOP_1 |
| 17 | 2026-02-27 | 000967 | 801970.SI | 0.5190 | TOP_1 |
| 18 | 2026-02-27 | 000988 |  | 0.5190 | TOP_1 |
| 19 | 2026-02-27 | 000999 | 801150.SI | 0.5190 | TOP_1 |
| 20 | 2026-02-27 | 001203 |  | 0.5190 | TOP_1 |

### Factor Weights

| Factor | Weight |
|--------|--------|
| quality_score | 0.10 |
| growth_acceleration_score | 0.10 |
| mainline_strength_score | 0.20 |
| capital_concentration_score | 0.15 |
| leader_dominance_score | 0.15 |
| trend_quality_score | 0.15 |
| lifecycle_position_score | 0.10 |
| risk_crowding_score | 0.05 |

### Flags Summary

| Flag | Count |
|------|-------|
| LIFECYCLE:UNKNOWN | 5175 |
| HIGH_ALPHA | 5158 |
| LOW_ALPHA | 17 |

### Daily Statistics

| Date | Count | Mean Score | Top 1 | Top 5 | Top 10 | Top 20 | Watch | Neutral | Avoid |
|------|-------|------------|-------|-------|--------|--------|-------|---------|-------|
| 2026-02-27 | 5175 | 0.5044 | 156 | 5002 | 0 | 0 | 0 | 0 | 17 |

