from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed

import pandas as pd
from sqlalchemy import text

from data_pipeline.common.cli import add_shared_args, month_chunks, quarter_periods, resolve_date_range
from data_pipeline.common.db import apply_sql_file, chunked_rows, get_engine
from data_pipeline.common.logging_utils import build_logger
from data_pipeline.common.state import BackfillState
from data_pipeline.tushare.client import TushareClient, resolve_tushare_token


def _to_date(series: pd.Series) -> pd.Series:
    return pd.to_datetime(series, format="%Y%m%d", errors="coerce").dt.date


def _prepare_income(frame: pd.DataFrame) -> list[dict]:
    if frame.empty:
        return []
    work = frame.copy()
    work["symbol"] = work["ts_code"].astype(str).str.split(".").str[0]
    for col in ("end_date", "ann_date", "f_ann_date"):
        work[col] = _to_date(work[col])
    for col in ("total_revenue", "revenue", "n_income_attr_p"):
        work[col] = pd.to_numeric(work.get(col), errors="coerce")
    work["source"] = "tushare_income"
    work = work.dropna(subset=["symbol", "end_date"])
    subset = work[["symbol", "end_date", "ann_date", "f_ann_date", "report_type", "total_revenue", "revenue", "n_income_attr_p", "source"]].copy()
    subset = subset.astype(object).where(pd.notna(subset), None)
    return subset.to_dict(orient="records")


def _prepare_balance(frame: pd.DataFrame) -> list[dict]:
    if frame.empty:
        return []
    work = frame.copy()
    work["symbol"] = work["ts_code"].astype(str).str.split(".").str[0]
    for col in ("end_date", "ann_date", "f_ann_date"):
        work[col] = _to_date(work[col])
    mappings = {
        "inventories": "inventory",
        "contract_liab": "contract_liability",
        "fix_assets": "fixed_assets",
        "total_assets": "total_assets",
        "total_liab": "total_liab",
    }
    for source_col, target_col in mappings.items():
        work[target_col] = pd.to_numeric(work.get(source_col), errors="coerce")
    work["source"] = "tushare_balancesheet"
    work = work.dropna(subset=["symbol", "end_date"])
    cols = ["symbol", "end_date", "ann_date", "f_ann_date", "report_type", "inventory", "contract_liability", "fixed_assets", "total_assets", "total_liab", "source"]
    subset = work[cols].copy()
    subset = subset.astype(object).where(pd.notna(subset), None)
    return subset.to_dict(orient="records")


def _prepare_fina(frame: pd.DataFrame) -> list[dict]:
    if frame.empty:
        return []
    work = frame.copy()
    work["symbol"] = work["ts_code"].astype(str).str.split(".").str[0]
    work["end_date"] = _to_date(work["end_date"])
    work["ann_date"] = _to_date(work["ann_date"])
    work["revenue_yoy"] = pd.to_numeric(work.get("or_yoy"), errors="coerce")
    work["revenue_yoy"] = work["revenue_yoy"].fillna(pd.to_numeric(work.get("tr_yoy"), errors="coerce"))
    work["revenue_yoy"] = work["revenue_yoy"].fillna(pd.to_numeric(work.get("q_sales_yoy"), errors="coerce"))
    work["profit_yoy"] = pd.to_numeric(work.get("netprofit_yoy"), errors="coerce")
    work["profit_yoy"] = work["profit_yoy"].fillna(pd.to_numeric(work.get("q_profit_yoy"), errors="coerce"))
    for col in ("roe", "grossprofit_margin", "debt_to_assets", "ocfps"):
        work[col] = pd.to_numeric(work.get(col), errors="coerce")
    work["gross_margin"] = work["grossprofit_margin"]
    work["source"] = "tushare_fina_indicator"
    work = work.dropna(subset=["symbol", "end_date"])
    cols = ["symbol", "end_date", "ann_date", "report_type", "revenue_yoy", "profit_yoy", "roe", "gross_margin", "debt_to_assets", "ocfps", "source"]
    subset = work[cols].copy()
    subset = subset.astype(object).where(pd.notna(subset), None)
    return subset.to_dict(orient="records")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Backfill quarterly Tushare fundamentals and expand to stock_fundamental_daily.")
    add_shared_args(parser)
    return parser


def _upsert_rows(engine, table_name: str, columns: list[str], rows: list[dict]) -> int:
    if not rows:
        return 0
    insert_cols = ", ".join(columns)
    values = ", ".join(f":{col}" for col in columns)
    updates = ", ".join(f"{col}=VALUES({col})" for col in columns if col not in {"symbol", "end_date"})
    sql = f"INSERT INTO {table_name} ({insert_cols}) VALUES ({values}) ON DUPLICATE KEY UPDATE {updates}, updated_at=CURRENT_TIMESTAMP"
    affected = 0
    with engine.begin() as conn:
        for batch in chunked_rows(rows, 4000):
            result = conn.execute(text(sql), batch)
            affected += int(result.rowcount or 0)
    return affected


def _fetch_period_dataset(client: TushareClient, api_name: str, period: str, fields: str) -> pd.DataFrame:
    return client.paginate(
        api_name,
        {"period": period},
        fields,
        page_size=5000,
        key_prefix=f"{api_name}|period={period}",
    )


def run(args: argparse.Namespace) -> None:
    date_range = resolve_date_range(args.start, args.end)
    logger = build_logger("build_stock_fundamental_daily")
    engine = get_engine()
    apply_sql_file(engine, "docs/DDL/ga_mainline_data_backfill_system.sql")
    token = resolve_tushare_token(args.token, args.config)
    client = TushareClient(token=token, logger=logger)
    raw_state = BackfillState(engine=engine, job_name="build_stock_fundamental_quarterly")
    daily_state = BackfillState(engine=engine, job_name="build_stock_fundamental_daily")
    periods = quarter_periods(date_range.start, date_range.end, lookback_years=2)

    datasets = [
        ("income", "ts_code,ann_date,f_ann_date,end_date,report_type,total_revenue,revenue,n_income_attr_p", _prepare_income, "local_stock_income_q", ["symbol", "end_date", "ann_date", "f_ann_date", "report_type", "total_revenue", "revenue", "n_income_attr_p", "source"]),
        ("balancesheet", "ts_code,ann_date,f_ann_date,end_date,report_type,inventories,contract_liab,fix_assets,total_assets,total_liab", _prepare_balance, "local_stock_balancesheet_q", ["symbol", "end_date", "ann_date", "f_ann_date", "report_type", "inventory", "contract_liability", "fixed_assets", "total_assets", "total_liab", "source"]),
        ("fina_indicator", "ts_code,ann_date,end_date,report_type,or_yoy,tr_yoy,q_sales_yoy,netprofit_yoy,q_profit_yoy,roe,grossprofit_margin,debt_to_assets,ocfps", _prepare_fina, "local_stock_fina_indicator_q", ["symbol", "end_date", "ann_date", "report_type", "revenue_yoy", "profit_yoy", "roe", "gross_margin", "debt_to_assets", "ocfps", "source"]),
    ]

    for api_name, fields, normalizer, table_name, columns in datasets:
        with ThreadPoolExecutor(max_workers=max(1, int(args.workers))) as pool:
            futures = {}
            for period in periods:
                chunk_key = f"{api_name}:{period}"
                if args.resume and raw_state.is_completed(chunk_key):
                    logger.info("resume_skip chunk=%s", chunk_key)
                    continue
                raw_state.start(chunk_key, None, None)
                futures[pool.submit(_fetch_period_dataset, client, api_name, period, fields)] = (chunk_key, period)
            for future in as_completed(futures):
                chunk_key, period = futures[future]
                try:
                    frame = future.result()
                    rows = normalizer(frame)
                    affected = _upsert_rows(engine, table_name, columns, rows)
                    raw_state.complete(chunk_key, affected)
                    logger.info("raw_chunk_done dataset=%s period=%s rows=%s affected=%s", api_name, period, len(rows), affected)
                except Exception as exc:
                    raw_state.fail(chunk_key, exc)
                    raise

    materialize_sql = """
    INSERT INTO stock_fundamental_daily (
        symbol, trade_date, report_end_date, ann_date, revenue_yoy, profit_yoy, roe,
        gross_margin, debt_to_assets, ocfps, inventory, contract_liability, fixed_assets, source
    )
    WITH report_keys AS (
        SELECT symbol, end_date FROM local_stock_income_q
        UNION
        SELECT symbol, end_date FROM local_stock_balancesheet_q
        UNION
        SELECT symbol, end_date FROM local_stock_fina_indicator_q
    ),
    merged AS (
        SELECT
            rk.symbol,
            rk.end_date,
            COALESCE(fi.ann_date, bs.f_ann_date, bs.ann_date, inc.f_ann_date, inc.ann_date, rk.end_date) AS ann_date,
            fi.revenue_yoy,
            fi.profit_yoy,
            fi.roe,
            fi.gross_margin,
            fi.debt_to_assets,
            fi.ocfps,
            bs.inventory,
            bs.contract_liability,
            bs.fixed_assets
        FROM report_keys rk
        LEFT JOIN local_stock_fina_indicator_q fi
          ON fi.symbol = rk.symbol
         AND fi.end_date = rk.end_date
        LEFT JOIN local_stock_balancesheet_q bs
          ON bs.symbol = rk.symbol
         AND bs.end_date = rk.end_date
        LEFT JOIN local_stock_income_q inc
          ON inc.symbol = rk.symbol
         AND inc.end_date = rk.end_date
    ),
    effective AS (
        SELECT
            merged.*,
            LEAD(COALESCE(merged.ann_date, merged.end_date)) OVER (
                PARTITION BY merged.symbol
                ORDER BY COALESCE(merged.ann_date, merged.end_date), merged.end_date
            ) AS next_ann_date
        FROM merged
    )
    SELECT
        p.SYMBOL,
        p.TRADE_DATE,
        e.end_date AS report_end_date,
        e.ann_date,
        e.revenue_yoy,
        e.profit_yoy,
        e.roe,
        e.gross_margin,
        e.debt_to_assets,
        e.ocfps,
        e.inventory,
        e.contract_liability,
        e.fixed_assets,
        'quarterly_snapshot' AS source
    FROM cn_stock_daily_price p
    JOIN effective e
      ON e.symbol = p.SYMBOL
     AND p.TRADE_DATE BETWEEN COALESCE(e.ann_date, e.end_date) AND COALESCE(DATE_SUB(e.next_ann_date, INTERVAL 1 DAY), :chunk_end)
    WHERE p.TRADE_DATE BETWEEN :chunk_start AND :chunk_end
      AND e.ann_date IS NOT NULL
    ON DUPLICATE KEY UPDATE
        report_end_date = VALUES(report_end_date),
        ann_date = VALUES(ann_date),
        revenue_yoy = VALUES(revenue_yoy),
        profit_yoy = VALUES(profit_yoy),
        roe = VALUES(roe),
        gross_margin = VALUES(gross_margin),
        debt_to_assets = VALUES(debt_to_assets),
        ocfps = VALUES(ocfps),
        inventory = VALUES(inventory),
        contract_liability = VALUES(contract_liability),
        fixed_assets = VALUES(fixed_assets),
        source = VALUES(source),
        updated_at = CURRENT_TIMESTAMP
    """
    total_daily = 0
    for chunk_start, chunk_end in month_chunks(date_range.start, date_range.end, max(1, int(args.chunk_months))):
        chunk_key = f"daily:{chunk_start}:{chunk_end}"
        if args.resume and daily_state.is_completed(chunk_key):
            logger.info("resume_skip chunk=%s", chunk_key)
            continue
        daily_state.start(chunk_key, chunk_start, chunk_end)
        try:
            with engine.begin() as conn:
                result = conn.execute(text(materialize_sql), {"chunk_start": chunk_start, "chunk_end": chunk_end})
            affected = int(result.rowcount or 0)
            total_daily += affected
            daily_state.complete(chunk_key, affected)
            logger.info("daily_chunk_done chunk=%s affected=%s", chunk_key, affected)
        except Exception as exc:
            daily_state.fail(chunk_key, exc)
            raise
    logger.info("build_stock_fundamental_daily_done affected=%s start=%s end=%s", total_daily, date_range.start, date_range.end)


def main() -> None:
    run(build_parser().parse_args())


if __name__ == "__main__":
    main()
