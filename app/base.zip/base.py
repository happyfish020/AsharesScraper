from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol

class Task(Protocol):
    name: str
    def run(self, ctx: "RunContext") -> None: ...

@dataclass
class RunContext:
    config: "RunnerConfig"
    engine: object
    log: object
