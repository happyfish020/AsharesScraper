"""Entry point (kept intentionally clean).

Policy:
- runner.py only wires the latest-trading-day run and delegates everything to app.cli
- category-specific logic lives in tasks/*
"""
from app.cli import run


if __name__ == "__main__":
    run()
