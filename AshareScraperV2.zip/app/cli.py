from __future__ import annotations

import argparse
from typing import List, Optional

from app.utils.logger import setup_logging, get_logger
from app.utils.wireguard_helper import activate_tunnel, toggle_vpn

from app.context import RunnerConfig
from app.base import RunContext
from app.runner_app import RunnerApp
from app.defaults import DEFAULT_INDEX_SYMBOLS, DEFAULT_BASE_INDEX
from app.settings import build_engine
from app.trading_day import get_latest_trade_date

from app.tasks.db_init_task import DbInitTask
from app.tasks.stock_loader_task import StockLoaderTask
from app.tasks.etf_loader_task import EtfLoaderTask
from app.tasks.index_loader_task import IndexLoaderTask
from app.tasks.futures_loader_task import FuturesLoaderTask
from app.tasks.options_loader_task import OptionsLoaderTask
from app.tasks.coverage_audit_task import CoverageAuditTask


def _parse_args(argv: Optional[List[str]] = None):
    p = argparse.ArgumentParser(description="AsharesScraper Runner")
    p.add_argument("--asof", default="latest", help="run as-of trading day: latest or YYYYMMDD")
    p.add_argument("--days", type=int, default=1, help="lookback window days (used when --asof=latest and you want backfill)")
    p.add_argument("--refresh", action="store_true", help="clear state files and refresh")
    p.add_argument("--no-vpn", action="store_true", help="skip wireguard start/stop")
    return p.parse_args(argv)


def run(argv: Optional[List[str]] = None) -> None:
    args = _parse_args(argv)

    setup_logging(market="cn", mode="scraper")
    log = get_logger("Runner")

    if not args.no_vpn:
        log.info("wireguard: start")
        activate_tunnel("cn")
        
    # resolve asof date
    if isinstance(args.asof, str) and args.asof.lower() == "latest":
        asof = get_latest_trade_date()
    else:
        asof = str(args.asof).strip()

    # RunnerConfig: keep tasks logic unchanged; we just drive an asof-centric window
    # - start_date=end_date=asof for true daily run
    # - if user wants backfill, they can pass --days and we set start based on finalize_dates
    cfg = RunnerConfig(
        look_back_days=args.days,
        manual_stock_symbols=[],
        index_symbols=DEFAULT_INDEX_SYMBOLS,
        base_index=DEFAULT_BASE_INDEX,
        refresh_state=args.refresh,
    )

    # If user explicitly targets a day, make runner strictly daily and clean.
    if asof and asof != "latest":
        cfg.start_date = asof
        cfg.end_date = asof
    else:
        # latest
        cfg.start_date = asof
        cfg.end_date = asof

    engine = build_engine()
    ctx = RunContext(config=cfg, engine=engine, log=log)

    tasks = [
        DbInitTask(),
        StockLoaderTask(),
        #EtfLoaderTask(),
        #FuturesLoaderTask(),
        #OptionsLoaderTask(),
        #IndexLoaderTask(),
 
        #CoverageAuditTask(),
    ]

    RunnerApp(ctx, tasks).run()
    activate_tunnel("cn")
    #if not args.no_vpn:
    #    log.info("wireguard: stop")
    #    toggle_vpn("cn", "stop")
