from __future__ import annotations

import os
from sqlalchemy import create_engine
from sqlalchemy.engine import Engine

def build_engine() -> Engine:
    """Build SQLAlchemy engine from env vars. Keep defaults stable with original runner."""
    db_user = os.getenv("ASHARE_DB_USER", "secopr")
    db_password = os.getenv("ASHARE_DB_PASSWORD", "secopr")
    db_host = os.getenv("ASHARE_DB_HOST", "localhost")
    db_port = os.getenv("ASHARE_DB_PORT", "1521")
    db_service = os.getenv("ASHARE_DB_SERVICE", "xe")

    dsn = f"{db_host}:{db_port}/{db_service}"
    conn = f"oracle+oracledb://{db_user}:{db_password}@{dsn}"
    return create_engine(conn, pool_pre_ping=True, future=True)
