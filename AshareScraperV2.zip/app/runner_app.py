from __future__ import annotations

from typing import List

from app.base import RunContext, Task
from app.context import RunnerConfig

class RunnerApp:
    def __init__(self, ctx: RunContext, tasks: List[Task]):
        self.ctx = ctx
        self.tasks = tasks

    def run(self) -> None:
        cfg = self.ctx.config
        if cfg.refresh_state:
            self._clear_state_files()

        self.ctx.log.info(f"启动 A股数据加载，回溯天数: {cfg.look_back_days} | start={cfg.start_date} end={cfg.end_date}")
        for i, task in enumerate(self.tasks, start=1):
            self.ctx.log.info(f"[TASK {i}/{len(self.tasks)}] {task.name} - START")
            task.run(self.ctx)
            self.ctx.log.info(f"[TASK {i}/{len(self.tasks)}] {task.name} - DONE")
        self.ctx.log.info("本次运行完成")

    def _clear_state_files(self) -> None:
        cfg = self.ctx.config
        for p in [cfg.scanned_file, cfg.failed_file]:
            try:
                if p.exists():
                    p.unlink()
            except Exception as e:
                self.ctx.log.warning(f"清空状态文件失败: {p} err={e}")
