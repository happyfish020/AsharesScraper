# Default symbols and constants for runner
DEFAULT_INDEX_SYMBOLS = [
    "sz399001",
    "sh000001",
    "sz399006",
    "sh000300",
    "sh000905",
    "sh000016",
    "sh000852",
]
DEFAULT_BASE_INDEX = "sh000300"
