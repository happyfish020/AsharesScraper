from __future__ import annotations

import os
import re
from dataclasses import dataclass
from datetime import datetime, date
from typing import Dict, Any, Set, Optional

from sqlalchemy import text

_BIND_RE = re.compile(r":([A-Za-z_][A-Za-z0-9_]*)")

def _parse_yyyymmdd(s: str) -> date:
    return datetime.strptime(s, "%Y%m%d").date()

def _needed_binds(plsql_block: str) -> Set[str]:
    return set(_BIND_RE.findall(plsql_block or ""))

def _build_bind_payload(needed: Set[str], *, run_id: Optional[str], start: str, end: str) -> Dict[str, Any]:
    """Provide a rich bind dict but only return keys referenced by the block."""
    sd = _parse_yyyymmdd(start)
    ed = _parse_yyyymmdd(end)

    # Common names people use in PL/SQL blocks
    full: Dict[str, Any] = {
        "run_id": run_id,
        "p_run_id": run_id,

        "start_yyyymmdd": start,
        "end_yyyymmdd": end,
        "start_date_yyyymmdd": start,
        "end_date_yyyymmdd": end,

        "start_date": sd,
        "end_date": ed,
        "p_start_date": sd,
        "p_end_date": ed,

        "asof_yyyymmdd": end,
        "trade_date_yyyymmdd": end,
        "signal_date_yyyymmdd": end,

        "asof_date": ed,
        "trade_date": ed,
        "signal_date": ed,
        "p_trade_date": ed,
        "p_signal_date": ed,
    }

    # Only return binds that are actually referenced in the block
    return {k: v for k, v in full.items() if k in needed}

@dataclass
class SectorRotationSnapshotTask:
    """Generate sector rotation ENTER/HOLD/EXIT snapshots by calling a stored procedure (SP).

    This task is **read-write** by design (it generates snapshot tables) but it never patches SPs.
    It only executes a user-provided PL/SQL block that calls the already-existing SP.

    Configuration (environment variables):
    - ROTATION_SNAPSHOT_SP_BLOCK (required):
        Example:
          BEGIN SECOPR.SP_REFRESH_SECTOR_ROTATION_DAILY(p_run_id=>:run_id, p_trade_date=>:trade_date); END;
        or (range mode):
          BEGIN SECOPR.SP_BUILD_SECTOR_ROT_SIGNAL(p_run_id=>:run_id, p_start_date=>:start_date, p_end_date=>:end_date); END;

    - ROTATION_SNAPSHOT_RUN_ID (optional):
        If your SP needs a run_id bind, set it here. If not referenced in the block, it's ignored.

    Behavior:
    - If the block references any of :start_date/:end_date (or *_yyyymmdd variants), we call it once.
    - Otherwise, we call it once using the as-of (end_date) binds.
    """

    name: str = "SectorRotationSnapshotTask"

    def run(self, ctx) -> None:
        cfg = ctx.config
        self.log = ctx.log
        self.engine=ctx.engine
        cfg.finalize_dates()
        start = str(cfg.start_date)
        end = str(cfg.end_date)

        plsql_block = os.getenv("ROTATION_SNAPSHOT_SP_BLOCK", "").strip()
        if not plsql_block:
            raise RuntimeError(
                "ROTATION_SNAPSHOT_SP_BLOCK is required. "
                "Provide a PL/SQL block that calls your existing SECOPR SP to generate ENTER/HOLD/EXIT snapshots."
            )

        run_id = os.getenv("ROTATION_SNAPSHOT_RUN_ID")
        needed = _needed_binds(plsql_block)

        # Sanity: if block references run_id but env missing -> fail fast
        if ("run_id" in needed or "p_run_id" in needed) and not run_id:
            raise RuntimeError(
                "Your ROTATION_SNAPSHOT_SP_BLOCK references :run_id (or :p_run_id) but ROTATION_SNAPSHOT_RUN_ID is not set."
            )

        payload = _build_bind_payload(needed, run_id=run_id, start=start, end=end)

        ctx.log.info(
            f"[rotation_snapshot] calling SP block; start={start} end={end} "
            f"binds={sorted(payload.keys())}"
        )

        # Execute with transaction
        with ctx.engine.begin() as conn:
            conn.execute(text(plsql_block), payload)

        ctx.log.info("[rotation_snapshot] done")
