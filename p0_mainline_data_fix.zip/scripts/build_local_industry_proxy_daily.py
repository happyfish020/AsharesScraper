"""
scripts/build_local_industry_proxy_daily.py
================================================
GrowthAlpha V8 — Build cn_local_industry_proxy_daily from stock prices and industry mapping.

Input tables:
  - cn_local_industry_map_hist (industry membership with in_date/out_date)
  - cn_stock_daily_price (daily OHLCV)
  - cn_stock_daily_basic (market cap, turnover)
  - cn_stock_leader_score_daily (optional, for leader_return)

Calculated metrics per (industry_id, trade_date):
  - member_count: number of constituent stocks
  - ret_eqw: equal-weighted return of constituents
  - amount_total: total turnover amount
  - turnover_avg: average turnover rate
  - market_cap_total: total market cap
  - leader_return: from leader_score_daily or top-5 return avg
  - top5_concentration: top-5 market cap / total market cap

Supports:
  - --start / --end date range
  - --resume (skip completed chunks)
  - --workers (parallel chunk processing)
  - --chunk-months (month count per chunk)

Usage:
  python scripts/build_local_industry_proxy_daily.py --start 2010-01-01 --end 2026-03-31 --resume --workers 4
"""

from __future__ import annotations

import argparse
import sys
from datetime import date, datetime
from typing import Any

from sqlalchemy import text

from app.settings import build_engine
from data_pipeline.common.cli import add_shared_args, month_chunks, resolve_date_range
from data_pipeline.common.db import apply_sql_file
from data_pipeline.common.logging_utils import build_logger
from data_pipeline.common.state import BackfillState


# ---------------------------------------------------------------------------
# SQL templates
# ---------------------------------------------------------------------------

# Main aggregation SQL: computes all proxy metrics from map_hist + daily_price + daily_basic
PROXY_AGG_SQL = """
INSERT INTO cn_local_industry_proxy_daily (
    industry_id, industry_name, trade_date, member_count, ret_eqw,
    amount_total, turnover_avg, market_cap_total, leader_return, top5_concentration
)
WITH base AS (
    SELECT
        m.industry_id,
        m.industry_name,
        p.trade_date,
        p.symbol,
        COALESCE(b.total_mv, b.circ_mv, 0) AS market_cap,
        COALESCE(p.amount, 0) AS amount,
        p.turnover_rate,
        CASE
            WHEN p.pre_close IS NOT NULL AND p.pre_close <> 0
                THEN (p.close / p.pre_close) - 1
            WHEN p.chg_pct IS NOT NULL AND ABS(p.chg_pct) > 1
                THEN p.chg_pct / 100
            WHEN p.chg_pct IS NOT NULL
                THEN p.chg_pct
            ELSE NULL
        END AS stock_ret
    FROM cn_local_industry_map_hist m
    JOIN cn_stock_daily_price p
        ON p.symbol = m.symbol
        AND p.trade_date BETWEEN m.in_date AND COALESCE(m.out_date, DATE('2099-12-31'))
    LEFT JOIN cn_stock_daily_basic b
        ON b.symbol = p.symbol
        AND b.trade_date = p.trade_date
    WHERE p.trade_date BETWEEN :chunk_start AND :chunk_end
      AND m.industry_level = :industry_level
),
ranked AS (
    SELECT
        base.*,
        ROW_NUMBER() OVER (
            PARTITION BY base.industry_id, base.trade_date
            ORDER BY base.market_cap DESC, base.symbol
        ) AS mc_rank
    FROM base
),
leader_agg AS (
    SELECT
        industry_id,
        trade_date,
        AVG(stock_ret) AS leader_return_avg
    FROM (
        SELECT
            industry_id,
            trade_date,
            stock_ret,
            ROW_NUMBER() OVER (
                PARTITION BY industry_id, trade_date
                ORDER BY COALESCE(stock_ret, -999) DESC
            ) AS ret_rank
        FROM base
        WHERE stock_ret IS NOT NULL
    ) t
    WHERE ret_rank <= 5
    GROUP BY industry_id, trade_date
)
SELECT
    r.industry_id,
    MAX(r.industry_name) AS industry_name,
    r.trade_date,
    COUNT(*) AS member_count,
    AVG(r.stock_ret) AS ret_eqw,
    SUM(r.amount) AS amount_total,
    AVG(r.turnover_rate) AS turnover_avg,
    SUM(r.market_cap) AS market_cap_total,
    COALESCE(
        (SELECT MAX(leader_return_avg) FROM leader_agg la
         WHERE la.industry_id = r.industry_id AND la.trade_date = r.trade_date),
        MAX(CASE WHEN r.mc_rank <= 5 THEN r.stock_ret ELSE NULL END)
    ) AS leader_return,
    CASE
        WHEN SUM(r.market_cap) = 0 THEN NULL
        ELSE SUM(CASE WHEN r.mc_rank <= 5 THEN r.market_cap ELSE 0 END) / SUM(r.market_cap)
    END AS top5_concentration
FROM ranked r
GROUP BY r.industry_id, r.trade_date
ON DUPLICATE KEY UPDATE
    industry_name = VALUES(industry_name),
    member_count = VALUES(member_count),
    ret_eqw = VALUES(ret_eqw),
    amount_total = VALUES(amount_total),
    turnover_avg = VALUES(turnover_avg),
    market_cap_total = VALUES(market_cap_total),
    leader_return = VALUES(leader_return),
    top5_concentration = VALUES(top5_concentration),
    updated_at = CURRENT_TIMESTAMP
"""

# Alternative: use leader_score_daily if available
PROXY_AGG_WITH_LEADER_SCORE_SQL = """
INSERT INTO cn_local_industry_proxy_daily (
    industry_id, industry_name, trade_date, member_count, ret_eqw,
    amount_total, turnover_avg, market_cap_total, leader_return, top5_concentration
)
WITH base AS (
    SELECT
        m.industry_id,
        m.industry_name,
        p.trade_date,
        p.symbol,
        COALESCE(b.total_mv, b.circ_mv, 0) AS market_cap,
        COALESCE(p.amount, 0) AS amount,
        p.turnover_rate,
        CASE
            WHEN p.pre_close IS NOT NULL AND p.pre_close <> 0
                THEN (p.close / p.pre_close) - 1
            WHEN p.chg_pct IS NOT NULL AND ABS(p.chg_pct) > 1
                THEN p.chg_pct / 100
            WHEN p.chg_pct IS NOT NULL
                THEN p.chg_pct
            ELSE NULL
        END AS stock_ret,
        ls.leader_score
    FROM cn_local_industry_map_hist m
    JOIN cn_stock_daily_price p
        ON p.symbol = m.symbol
        AND p.trade_date BETWEEN m.in_date AND COALESCE(m.out_date, DATE('2099-12-31'))
    LEFT JOIN cn_stock_daily_basic b
        ON b.symbol = p.symbol
        AND b.trade_date = p.trade_date
    LEFT JOIN cn_stock_leader_score_daily ls
        ON ls.symbol = p.symbol
        AND ls.trade_date = p.trade_date
    WHERE p.trade_date BETWEEN :chunk_start AND :chunk_end
      AND m.industry_level = :industry_level
),
ranked AS (
    SELECT
        base.*,
        ROW_NUMBER() OVER (
            PARTITION BY base.industry_id, base.trade_date
            ORDER BY COALESCE(base.leader_score, -999) DESC, base.market_cap DESC
        ) AS leader_rank,
        ROW_NUMBER() OVER (
            PARTITION BY base.industry_id, base.trade_date
            ORDER BY base.market_cap DESC, base.symbol
        ) AS mc_rank
    FROM base
)
SELECT
    r.industry_id,
    MAX(r.industry_name) AS industry_name,
    r.trade_date,
    COUNT(*) AS member_count,
    AVG(r.stock_ret) AS ret_eqw,
    SUM(r.amount) AS amount_total,
    AVG(r.turnover_rate) AS turnover_avg,
    SUM(r.market_cap) AS market_cap_total,
    MAX(CASE WHEN r.leader_rank = 1 THEN r.stock_ret ELSE NULL END) AS leader_return,
    CASE
        WHEN SUM(r.market_cap) = 0 THEN NULL
        ELSE SUM(CASE WHEN r.mc_rank <= 5 THEN r.market_cap ELSE 0 END) / SUM(r.market_cap)
    END AS top5_concentration
FROM ranked r
GROUP BY r.industry_id, r.trade_date
ON DUPLICATE KEY UPDATE
    industry_name = VALUES(industry_name),
    member_count = VALUES(member_count),
    ret_eqw = VALUES(ret_eqw),
    amount_total = VALUES(amount_total),
    turnover_avg = VALUES(turnover_avg),
    market_cap_total = VALUES(market_cap_total),
    leader_return = VALUES(leader_return),
    top5_concentration = VALUES(top5_concentration),
    updated_at = CURRENT_TIMESTAMP
"""


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def check_leader_score_table(engine) -> bool:
    """Check if cn_stock_leader_score_daily exists and has data."""
    with engine.connect() as conn:
        exists = conn.execute(
            text(
                """
                SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES
                WHERE TABLE_SCHEMA = DATABASE()
                  AND TABLE_NAME = 'cn_stock_leader_score_daily'
                """
            )
        ).scalar()
        if not exists:
            return False
        has_data = conn.execute(
            text("SELECT COUNT(*) FROM cn_stock_leader_score_daily LIMIT 1")
        ).scalar()
        return has_data > 0


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="GrowthAlpha V8 — Build cn_local_industry_proxy_daily from stock prices and industry mapping"
    )
    parser.add_argument("--start", default="2010-01-01", help="Start date YYYY-MM-DD or YYYYMMDD")
    parser.add_argument("--end", default="", help="End date YYYY-MM-DD or YYYYMMDD (default: today)")
    parser.add_argument("--resume", action="store_true", help="Skip completed chunks in mainline_backfill_job_state")
    parser.add_argument("--force", action="store_true", help="Force rebuild even if completed")
    parser.add_argument("--workers", type=int, default=4, help="Parallel workers (for future use)")
    parser.add_argument("--chunk-months", type=int, default=1, help="Month count per chunk")
    parser.add_argument("--industry-level", default="L1", choices=["L1", "L2", "L3"], help="Industry level")
    parser.add_argument("--use-leader-score", action="store_true", help="Use cn_stock_leader_score_daily for leader_return (auto-detected if available)")
    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()

    date_range = resolve_date_range(args.start, args.end)
    logger = build_logger("build_local_industry_proxy_daily")
    engine = build_engine()

    # Ensure DDL
    logger.info("Ensuring cn_local_industry_proxy_daily table exists")
    ddl_check_sql = """
    CREATE TABLE IF NOT EXISTS `cn_local_industry_proxy_daily` (
        `industry_id` VARCHAR(32) NOT NULL,
        `industry_name` VARCHAR(128) DEFAULT NULL,
        `trade_date` DATE NOT NULL,
        `member_count` INT NOT NULL DEFAULT 0,
        `ret_eqw` DECIMAL(18,8) DEFAULT NULL,
        `amount_total` DECIMAL(24,4) DEFAULT NULL,
        `turnover_avg` DECIMAL(18,6) DEFAULT NULL,
        `market_cap_total` DECIMAL(24,4) DEFAULT NULL,
        `leader_return` DECIMAL(18,8) DEFAULT NULL,
        `top5_concentration` DECIMAL(18,8) DEFAULT NULL,
        `created_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
        `updated_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY `uk_industry_trade_date` (`industry_id`, `trade_date`),
        KEY `idx_trade_date` (`trade_date`),
        KEY `idx_industry_id` (`industry_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    """
    with engine.begin() as conn:
        conn.execute(text(ddl_check_sql))

    # Ensure backfill state table
    state_ddl = """
    CREATE TABLE IF NOT EXISTS `mainline_backfill_job_state` (
        `job_name` VARCHAR(64) NOT NULL,
        `chunk_key` VARCHAR(128) NOT NULL,
        `range_start` DATE DEFAULT NULL,
        `range_end` DATE DEFAULT NULL,
        `status` VARCHAR(16) NOT NULL,
        `attempts` INT NOT NULL DEFAULT 0,
        `last_rows` BIGINT NOT NULL DEFAULT 0,
        `last_error` TEXT DEFAULT NULL,
        `last_run_id` VARCHAR(64) DEFAULT NULL,
        `updated_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        `created_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`job_name`, `chunk_key`),
        KEY `idx_mainline_backfill_job_state_status` (`status`, `updated_at`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    """
    with engine.begin() as conn:
        conn.execute(text(state_ddl))

    state = BackfillState(engine=engine, job_name=f"build_local_industry_proxy_daily_{args.industry_level}")

    # Auto-detect leader score availability
    use_leader_score = args.use_leader_score or check_leader_score_table(engine)
    agg_sql = PROXY_AGG_WITH_LEADER_SCORE_SQL if use_leader_score else PROXY_AGG_SQL
    logger.info(
        "Starting build level=%s start=%s end=%s resume=%s force=%s chunk_months=%s use_leader_score=%s",
        args.industry_level,
        date_range.start,
        date_range.end,
        args.resume,
        args.force,
        args.chunk_months,
        use_leader_score,
    )

    total_affected = 0
    chunks = month_chunks(date_range.start, date_range.end, max(1, int(args.chunk_months)))
    logger.info("Processing %s chunks", len(chunks))

    for chunk_idx, (chunk_start, chunk_end) in enumerate(chunks, start=1):
        chunk_key = f"{args.industry_level}:{chunk_start}:{chunk_end}"
        if args.resume and state.is_completed(chunk_key) and not args.force:
            logger.info("[%s/%s] resume_skip chunk=%s", chunk_idx, len(chunks), chunk_key)
            continue

        state.start(chunk_key, chunk_start, chunk_end)
        logger.info("[%s/%s] processing %s..%s", chunk_idx, len(chunks), chunk_start, chunk_end)

        try:
            with engine.begin() as conn:
                result = conn.execute(
                    text(agg_sql),
                    {
                        "industry_level": args.industry_level,
                        "chunk_start": chunk_start,
                        "chunk_end": chunk_end,
                    },
                )
            affected = int(result.rowcount or 0)
            total_affected += affected
            state.complete(chunk_key, affected)
            logger.info("[%s/%s] chunk_done chunk=%s affected=%s", chunk_idx, len(chunks), chunk_key, affected)
        except Exception as exc:
            state.fail(chunk_key, exc)
            logger.error("[%s/%s] chunk_failed chunk=%s err=%s", chunk_idx, len(chunks), chunk_key, exc)
            # Continue with next chunk
            continue

    # Summary
    with engine.connect() as conn:
        summary = conn.execute(
            text(
                """
                SELECT COUNT(*) AS row_cnt,
                       COUNT(DISTINCT industry_id) AS industry_cnt,
                       MIN(trade_date) AS min_trade_date,
                       MAX(trade_date) AS max_trade_date
                FROM cn_local_industry_proxy_daily
                """
            )
        ).one()

    logger.info(
        "build_local_industry_proxy_daily done "
        "level=%s affected=%s chunks=%s "
        "table_rows=%s industries=%s date_range=%s..%s",
        args.industry_level,
        total_affected,
        len(chunks),
        summary[0],
        summary[1],
        summary[2],
        summary[3],
    )
    print(
        f"\n=== build_local_industry_proxy_daily complete ==="
        f"\n  Level:      {args.industry_level}"
        f"\n  Affected:   {total_affected:,}"
        f"\n  Chunks:     {len(chunks)}"
        f"\n  Table:      {summary[0]:,} rows, {summary[1]} industries"
        f"\n  Date range: {summary[2]} -> {summary[3]}"
    )


if __name__ == "__main__":
    main()
