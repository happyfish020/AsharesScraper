"""
scripts/build_local_industry_map_hist.py
============================================
GrowthAlpha V8 — Build cn_local_industry_map_hist from Tushare SW industry membership.

Data sources (priority order):
  1. cn_board_member_map_d (existing board membership)
  2. Tushare index_member_all (SW industry membership history)

Generates:
  - symbol, industry_id, industry_name, industry_level
  - in_date, out_date, is_current
  - source, updated_at

Supports:
  - SW L1 (default), L2, L3
  - --start / --end date range
  - --resume (skip completed chunks)
  - --force (reprocess even if completed)
  - Avoids future function: in_date/out_date from Tushare are historical facts

Usage:
  python scripts/build_local_industry_map_hist.py --start 2010-01-01 --end 2026-03-31 --level L1 --resume
"""

from __future__ import annotations

import argparse
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import date, datetime
from typing import Any

import pandas as pd
from sqlalchemy import text

from app.settings import build_engine
from data_pipeline.common.cli import add_shared_args, resolve_date_range
from data_pipeline.common.db import chunked_rows, fetch_df
from data_pipeline.common.logging_utils import build_logger
from data_pipeline.common.state import BackfillState
from data_pipeline.tushare.client import TushareClient, resolve_tushare_token


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _to_date(value: object) -> date | None:
    if value in (None, "", "None", "nan", "NaT"):
        return None
    dt = pd.to_datetime(value, format="%Y%m%d", errors="coerce")
    if pd.isna(dt):
        return None
    return dt.date()


def _normalize_symbol(value: object) -> str:
    text = str(value or "").strip()
    return text.split(".", 1)[0] if "." in text else text


def _parse_date(value: Any) -> date | None:
    if value is None:
        return None
    if isinstance(value, date):
        return value
    if isinstance(value, datetime):
        return value.date()
    try:
        return datetime.strptime(str(value)[:10], "%Y-%m-%d").date()
    except (ValueError, TypeError):
        pass
    try:
        return datetime.strptime(str(value).strip(), "%Y%m%d").date()
    except (ValueError, TypeError):
        pass
    return None


# ---------------------------------------------------------------------------
# Source 1: cn_board_member_map_d
# ---------------------------------------------------------------------------


def fetch_board_member_map(engine, start: date, end: date, level: str) -> list[dict]:
    """Extract industry membership from cn_board_member_map_d.

    This table has trade_date-level membership snapshots. We derive in_date/out_date
    by tracking when a symbol first appears / last appears in an industry.
    """
    logger = build_logger("build_local_industry_map_hist")
    logger.info("Fetching board member map for level=%s range=%s..%s", level, start, end)

    # Map board_type to industry level
    level_map = {"L1": "I", "L2": "I", "L3": "I"}  # cn_board_member_map_d uses sector_type='I' for industry

    sql = """
    SELECT trade_date, sector_id, sector_name, symbol
    FROM cn_board_member_map_d
    WHERE trade_date BETWEEN :start AND :end
      AND sector_type = :sector_type
    ORDER BY sector_id, symbol, trade_date
    """
    with engine.connect() as conn:
        df = pd.read_sql(text(sql), conn, params={"start": start, "end": end, "sector_type": level_map.get(level, "I")})

    if df.empty:
        logger.info("No board member map data found for level=%s", level)
        return []

    # Group by (sector_id, symbol) to derive in_date/out_date
    rows: list[dict] = []
    for (sector_id, symbol), group in df.groupby(["sector_id", "symbol"]):
        group = group.sort_values("trade_date")
        trade_dates = group["trade_date"].tolist()
        sector_name = group["sector_name"].iloc[0] if "sector_name" in group.columns else sector_id

        # in_date = first appearance, out_date = last appearance + 1 day
        in_date = _parse_date(trade_dates[0])
        out_date = _parse_date(trade_dates[-1])

        # If out_date is the last date in range, it might still be current
        is_current = 1 if out_date and out_date >= end else 0

        rows.append(
            {
                "symbol": _normalize_symbol(symbol),
                "industry_id": str(sector_id).strip(),
                "industry_name": str(sector_name).strip(),
                "industry_level": level,
                "in_date": in_date,
                "out_date": out_date,
                "is_current": is_current,
                "source": "cn_board_member_map_d",
            }
        )

    logger.info("Board member map derived %s membership records", len(rows))
    return rows


# ---------------------------------------------------------------------------
# Source 2: Tushare index_member_all
# ---------------------------------------------------------------------------


def fetch_industry_master(engine, src: str, level: str) -> pd.DataFrame:
    """Fetch industry master from local_industry_master or Tushare."""
    df = fetch_df(
        engine,
        """
        SELECT industry_id, industry_name, industry_level, src
        FROM local_industry_master
        WHERE src = :src AND industry_level = :level
        ORDER BY industry_id
        """,
        {"src": src, "level": level},
    )
    if not df.empty:
        return df

    # Fallback: fetch from Tushare and insert
    logger = build_logger("build_local_industry_map_hist")
    logger.info("local_industry_master empty for src=%s level=%s, fetching from Tushare", src, level)
    token = resolve_tushare_token("", "")
    client = TushareClient(token=token, logger=logger)
    frame = client.call(
        "index_classify",
        {"src": src, "level": level},
        "index_code,industry_name,level,parent_code,src",
        cache_key=f"index_classify|src={src}|level={level}",
    )
    if frame.empty:
        raise SystemExit(f"No industry data from Tushare for src={src} level={level}")

    rows = []
    for item in frame.to_dict(orient="records"):
        rows.append(
            {
                "industry_id": str(item.get("index_code") or "").strip(),
                "industry_name": str(item.get("industry_name") or "").strip(),
                "industry_level": str(item.get("level") or level).strip(),
                "parent_id": str(item.get("parent_code") or "").strip() or None,
                "src": src,
            }
        )

    insert_sql = """
    INSERT INTO local_industry_master
        (industry_id, industry_name, industry_level, parent_id, src)
    VALUES
        (:industry_id, :industry_name, :industry_level, :parent_id, :src)
    ON DUPLICATE KEY UPDATE
        industry_name = VALUES(industry_name),
        industry_level = VALUES(industry_level),
        parent_id = VALUES(parent_id),
        src = VALUES(src)
    """
    with engine.begin() as conn:
        for batch in chunked_rows(rows, 500):
            conn.execute(text(insert_sql), batch)

    return fetch_df(
        engine,
        """
        SELECT industry_id, industry_name, industry_level, src
        FROM local_industry_master
        WHERE src = :src AND industry_level = :level
        ORDER BY industry_id
        """,
        {"src": src, "level": level},
    )


def fetch_tushare_member_hist(
    client: TushareClient,
    industry_id: str,
    start: date,
    end: date,
    logger: Any,
) -> list[dict]:
    """Fetch index_member_all for one industry and derive in_date/out_date."""
    frame = client.paginate(
        "index_member_all",
        {"ts_code": industry_id},
        "index_code,con_code,in_date,out_date,is_new",
        page_size=5000,
        key_prefix=f"index_member_all|industry_id={industry_id}",
    )

    rows: list[dict] = []
    for item in frame.to_dict(orient="records"):
        in_date = _to_date(item.get("in_date"))
        out_date = _to_date(item.get("out_date"))

        if in_date is None:
            continue
        if in_date > end:
            continue
        if out_date is not None and out_date < start:
            continue

        is_current = 1 if out_date is None or out_date >= end else 0

        rows.append(
            {
                "symbol": _normalize_symbol(item.get("con_code")),
                "industry_id": industry_id,
                "in_date": in_date,
                "out_date": out_date,
                "is_current": is_current,
                "source": "tushare_index_member_all",
            }
        )
    return rows


# ---------------------------------------------------------------------------
# Merge and upsert
# ---------------------------------------------------------------------------


def upsert_map_hist(engine, rows: list[dict], chunk_size: int = 5000) -> int:
    """Upsert rows into cn_local_industry_map_hist. Returns affected count."""
    if not rows:
        return 0

    insert_sql = """
    INSERT INTO cn_local_industry_map_hist
        (symbol, industry_id, industry_name, industry_level, in_date, out_date, is_current, source)
    VALUES
        (:symbol, :industry_id, :industry_name, :industry_level, :in_date, :out_date, :is_current, :source)
    ON DUPLICATE KEY UPDATE
        industry_name = VALUES(industry_name),
        industry_level = VALUES(industry_level),
        out_date = VALUES(out_date),
        is_current = VALUES(is_current),
        source = VALUES(source),
        updated_at = CURRENT_TIMESTAMP
    """
    affected = 0
    with engine.begin() as conn:
        for batch in chunked_rows(rows, chunk_size):
            ret = conn.execute(text(insert_sql), batch)
            affected += int(ret.rowcount or 0)
    return affected


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="GrowthAlpha V8 — Build cn_local_industry_map_hist from Tushare SW membership"
    )
    parser.add_argument("--start", default="2010-01-01", help="Start date YYYY-MM-DD or YYYYMMDD")
    parser.add_argument("--end", default="", help="End date YYYY-MM-DD or YYYYMMDD (default: today)")
    parser.add_argument("--level", default="L1", choices=["L1", "L2", "L3"], help="Industry level")
    parser.add_argument("--resume", action="store_true", help="Skip completed chunks")
    parser.add_argument("--force", action="store_true", help="Force reprocess even if completed")
    parser.add_argument("--workers", type=int, default=4, help="Parallel workers for Tushare fetch")
    parser.add_argument("--token", default="", help="Tushare token")
    parser.add_argument("--config", default="", help="Optional config path for Tushare token")
    parser.add_argument("--src", default="SW2021", help="Tushare industry classification source")
    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()

    date_range = resolve_date_range(args.start, args.end)
    logger = build_logger("build_local_industry_map_hist")
    engine = build_engine()

    # Ensure DDL
    logger.info("Ensuring cn_local_industry_map_hist table exists")
    ddl_check_sql = """
    CREATE TABLE IF NOT EXISTS `cn_local_industry_map_hist` (
        `symbol` VARCHAR(10) NOT NULL,
        `industry_id` VARCHAR(32) NOT NULL,
        `industry_name` VARCHAR(128) NOT NULL,
        `industry_level` VARCHAR(8) NOT NULL,
        `in_date` DATE NOT NULL,
        `out_date` DATE DEFAULT NULL,
        `is_current` TINYINT(1) NOT NULL DEFAULT 0,
        `source` VARCHAR(32) DEFAULT NULL,
        `updated_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        `created_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`symbol`, `industry_id`, `in_date`),
        KEY `idx_symbol_date` (`symbol`, `in_date`, `out_date`),
        KEY `idx_industry_date` (`industry_id`, `in_date`, `out_date`),
        KEY `idx_current` (`is_current`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    """
    with engine.begin() as conn:
        conn.execute(text(ddl_check_sql))

    # Ensure backfill state table
    state_ddl = """
    CREATE TABLE IF NOT EXISTS `mainline_backfill_job_state` (
        `job_name` VARCHAR(64) NOT NULL,
        `chunk_key` VARCHAR(128) NOT NULL,
        `range_start` DATE DEFAULT NULL,
        `range_end` DATE DEFAULT NULL,
        `status` VARCHAR(16) NOT NULL,
        `attempts` INT NOT NULL DEFAULT 0,
        `last_rows` BIGINT NOT NULL DEFAULT 0,
        `last_error` TEXT DEFAULT NULL,
        `last_run_id` VARCHAR(64) DEFAULT NULL,
        `updated_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        `created_at` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`job_name`, `chunk_key`),
        KEY `idx_mainline_backfill_job_state_status` (`status`, `updated_at`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
    """
    with engine.begin() as conn:
        conn.execute(text(state_ddl))

    state = BackfillState(engine=engine, job_name=f"build_local_industry_map_hist_{args.level}")
    token = resolve_tushare_token(args.token, args.config)
    client = TushareClient(token=token, logger=logger)

    logger.info(
        "Starting build level=%s start=%s end=%s resume=%s force=%s workers=%s",
        args.level,
        date_range.start,
        date_range.end,
        args.resume,
        args.force,
        args.workers,
    )

    # Step 1: Try cn_board_member_map_d first
    board_rows = fetch_board_member_map(engine, date_range.start, date_range.end, args.level)
    logger.info("Board member map yielded %s records", len(board_rows))

    # Step 2: Fetch from Tushare index_member_all
    master = fetch_industry_master(engine, args.src, args.level)
    if master.empty:
        raise SystemExit(f"No industry master found for src={args.src} level={args.level}")

    logger.info("Industry master has %s industries", len(master))

    # Build lookup for industry names
    lookup = {}
    for row in master.itertuples(index=False):
        lookup[str(row.industry_id)] = {
            "industry_name": str(row.industry_name),
            "industry_level": str(row.industry_level),
        }

    # Collect existing symbols from board data to avoid duplicates
    existing_keys: set[tuple[str, str]] = set()
    for row in board_rows:
        existing_keys.add((row["symbol"], row["industry_id"]))

    total_rows = len(board_rows)
    total_affected = upsert_map_hist(engine, board_rows)
    logger.info("Upserted %s board-derived records (affected=%s)", len(board_rows), total_affected)

    # Step 3: Fetch Tushare membership per industry (parallel)
    tushare_rows: list[dict] = []
    industry_ids = list(lookup.keys())

    with ThreadPoolExecutor(max_workers=max(1, int(args.workers))) as pool:
        futures = {}
        for industry_id in industry_ids:
            chunk_key = f"{args.src}:{args.level}:{industry_id}"
            if args.resume and state.is_completed(chunk_key) and not args.force:
                logger.info("resume_skip chunk=%s", chunk_key)
                continue
            state.start(chunk_key, date_range.start, date_range.end)
            futures[pool.submit(fetch_tushare_member_hist, client, industry_id, date_range.start, date_range.end, logger)] = chunk_key

        for future in as_completed(futures):
            chunk_key = futures[future]
            industry_id = chunk_key.rsplit(":", 1)[-1]
            info = lookup.get(industry_id, {})
            try:
                raw_rows = future.result()
                # Deduplicate against board data
                new_rows = []
                for row in raw_rows:
                    key = (row["symbol"], row["industry_id"])
                    if key not in existing_keys:
                        row["industry_name"] = info.get("industry_name", industry_id)
                        row["industry_level"] = info.get("industry_level", args.level)
                        new_rows.append(row)
                        existing_keys.add(key)

                if new_rows:
                    affected = upsert_map_hist(engine, new_rows)
                    total_affected += affected
                    total_rows += len(new_rows)

                state.complete(chunk_key, len(new_rows))
                logger.info("chunk_done chunk=%s rows=%s new=%s", chunk_key, len(raw_rows), len(new_rows))
                tushare_rows.extend(new_rows)

            except Exception as exc:
                state.fail(chunk_key, exc)
                logger.error("chunk_failed chunk=%s err=%s", chunk_key, exc)
                continue

    # Summary
    with engine.connect() as conn:
        summary = conn.execute(
            text(
                """
                SELECT COUNT(*) AS row_cnt,
                       COUNT(DISTINCT symbol) AS symbol_cnt,
                       COUNT(DISTINCT industry_id) AS industry_cnt,
                       MIN(in_date) AS min_in_date,
                       MAX(in_date) AS max_in_date
                FROM cn_local_industry_map_hist
                WHERE industry_level = :level
                """
            ),
            {"level": args.level},
        ).one()

    logger.info(
        "build_local_industry_map_hist done "
        "level=%s board_rows=%s tushare_rows=%s total_rows=%s affected=%s "
        "table_rows=%s symbols=%s industries=%s in_date_range=%s..%s",
        args.level,
        len(board_rows),
        len(tushare_rows),
        total_rows,
        total_affected,
        summary[0],
        summary[1],
        summary[2],
        summary[3],
        summary[4],
    )
    print(
        f"\n=== build_local_industry_map_hist complete ==="
        f"\n  Level:      {args.level}"
        f"\n  Board rows: {len(board_rows)}"
        f"\n  Tushare rows: {len(tushare_rows)}"
        f"\n  Total rows: {total_rows}"
        f"\n  Affected:   {total_affected}"
        f"\n  Table:      {summary[0]:,} rows, {summary[1]} symbols, {summary[2]} industries"
        f"\n  Date range: {summary[3]} -> {summary[4]}"
    )


if __name__ == "__main__":
    main()
