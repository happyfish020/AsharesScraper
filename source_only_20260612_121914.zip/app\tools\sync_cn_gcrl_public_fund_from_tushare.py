from __future__ import annotations

import argparse
import builtins
import math
import re
import time
from dataclasses import dataclass
from datetime import date, datetime, timedelta
from io import StringIO
from typing import Iterable, List, Sequence

import pandas as pd
import requests
import tushare as ts
from sqlalchemy import text

from app.settings import build_engine, load_sql_for_current_db
from app.tools.sync_cn_stock_daily_price_from_tushare import (
    patch_pandas_fillna_method_compat,
    resolve_tushare_token,
)

try:
    from app.utils.progress import ProgressLogger  # noqa: F401
except Exception:  # pragma: no cover
    ProgressLogger = None  # type: ignore


def print(*args, **kwargs):
    kwargs.setdefault("flush", True)
    return builtins.print(*args, **kwargs)


DDL_PATH = "docs/DDL/cn_market.cn_gcrl_public_fund.sql"
SOURCE_FUND_BASIC = "tushare_fund_basic"
SOURCE_FUND_PORTFOLIO = "tushare_fund_portfolio"
SOURCE_EASTMONEY_HOLDING = "eastmoney_fund_archives_jjcc"

# First batch: CN public fund companies focused on A-share mainline reference.
DEFAULT_PUBLIC_FUND_INSTITUTIONS = [
    ("CN_PUBFUND_EFUND", "易方达基金管理有限公司", "易方达", 1),
    ("CN_PUBFUND_CHINAAMC", "华夏基金管理有限公司", "华夏基金", 1),
    ("CN_PUBFUND_HARVEST", "嘉实基金管理有限公司", "嘉实基金", 1),
    ("CN_PUBFUND_FULLGOAL", "富国基金管理有限公司", "富国基金", 1),
    ("CN_PUBFUND_SOUTHERN", "南方基金管理股份有限公司", "南方基金", 1),
    ("CN_PUBFUND_99FUND", "汇添富基金管理股份有限公司", "汇添富", 1),
    ("CN_PUBFUND_IGW", "景顺长城基金管理有限公司", "景顺长城", 1),
    ("CN_PUBFUND_GFFUNDS", "广发基金管理有限公司", "广发基金", 1),
    ("CN_PUBFUND_CMF", "招商基金管理有限公司", "招商基金", 1),
    ("CN_PUBFUND_BOSERA", "博时基金管理有限公司", "博时基金", 1),
    ("CN_PUBFUND_CGF", "中欧基金管理有限公司", "中欧基金", 1),
    ("CN_PUBFUND_XQGLOBAL", "兴证全球基金管理有限公司", "兴证全球", 1),
    ("CN_PUBFUND_YH", "银华基金管理股份有限公司", "银华基金", 1),
    ("CN_PUBFUND_ICBCCS", "工银瑞信基金管理有限公司", "工银瑞信", 1),
    ("CN_PUBFUND_BOCOM", "交银施罗德基金管理有限公司", "交银施罗德", 1),
]

FUND_BASIC_FIELDS = (
    "ts_code,name,management,custodian,fund_type,found_date,due_date,list_date,"
    "issue_date,delist_date,issue_amount,m_fee,c_fee,duration_year,p_value,min_amount,"
    "exp_return,benchmark,status,invest_type,type,trustee,purc_startdate,redm_startdate,market"
)
FUND_PORTFOLIO_FIELDS = "ts_code,ann_date,end_date,symbol,mkv,amount,stk_mkv_ratio,stk_float_ratio"


@dataclass(frozen=True)
class InstitutionSeed:
    institution_id: str
    institution_name: str
    short_name: str
    tier: int = 1


class OptionalSourceUnavailable(RuntimeError):
    """Raised when an optional upstream source has no permission or is unavailable."""


def _parse_ymd(raw: str) -> date:
    s = str(raw or "").strip()
    if len(s) == 10 and s[4] == "-" and s[7] == "-":
        return datetime.strptime(s, "%Y-%m-%d").date()
    return datetime.strptime(s, "%Y%m%d").date()


def _to_date_series(series: pd.Series) -> pd.Series:
    return pd.to_datetime(series, format="%Y%m%d", errors="coerce").dt.date


def _to_report_period(raw: str) -> date:
    return _parse_ymd(raw)


def _prev_quarter_end(d: date) -> date:
    month = ((d.month - 1) // 3) * 3 + 1
    return date(d.year, month, 1) - timedelta(days=1)


def _report_month(d: date) -> int:
    return {3: 3, 6: 6, 9: 9, 12: 12}.get(d.month, d.month)


def _chunked(records: Sequence[dict], chunk_size: int) -> Iterable[Sequence[dict]]:
    for i in range(0, len(records), chunk_size):
        yield records[i : i + chunk_size]


def _safe_scalar(value):
    if value is None:
        return None
    try:
        if pd.isna(value):
            return None
    except Exception:
        pass
    if isinstance(value, float) and (math.isnan(value) or math.isinf(value)):
        return None
    return value


def _df_records(df: pd.DataFrame) -> list[dict]:
    if df is None or df.empty:
        return []
    clean = df.replace([float("inf"), float("-inf")], pd.NA)
    records = clean.astype(object).where(pd.notna(clean), None).to_dict(orient="records")
    return [{k: _safe_scalar(v) for k, v in row.items()} for row in records]


def _fund_plain_code(fund_code: object) -> str:
    s = str(fund_code or "").strip()
    return s.split(".")[0].zfill(6) if s else ""


def _stock_code_with_exchange(symbol: object) -> str:
    s = re.sub(r"\D", "", str(symbol or "").strip())
    if len(s) != 6:
        return s
    if s.startswith(("6", "9")):
        return f"{s}.SH"
    return f"{s}.SZ"


def _parse_cn_number(raw) -> float | None:
    if raw is None:
        return None
    s = str(raw).strip().replace(",", "").replace("%", "")
    s = s.replace("--", "").replace("-", "") if s in {"--", "-"} else s
    if not s:
        return None
    multiplier = 1.0
    if "亿" in s:
        multiplier = 100000000.0
        s = s.replace("亿", "")
    elif "万" in s:
        multiplier = 10000.0
        s = s.replace("万", "")
    s = re.sub(r"[^0-9.\-]", "", s)
    if not s or s in {".", "-"}:
        return None
    try:
        return float(s) * multiplier
    except Exception:
        return None


def apply_ddl(engine) -> None:
    sql = load_sql_for_current_db(DDL_PATH)
    with engine.begin() as conn:
        for stmt in [part.strip() for part in sql.split(";") if part.strip()]:
            conn.execute(text(stmt))


def ensure_tables(engine) -> None:
    apply_ddl(engine)


def seed_institution_registry(engine) -> int:
    records = [
        {
            "institution_id": x[0],
            "institution_name": x[1],
            "institution_short_name": x[2],
            "tier": int(x[3]),
        }
        for x in DEFAULT_PUBLIC_FUND_INSTITUTIONS
    ]
    sql = text(
        """
        INSERT INTO cn_gcrl_institution_registry
            (institution_id, institution_name, institution_short_name, country, institution_type, tier, source, is_active)
        VALUES
            (:institution_id, :institution_name, :institution_short_name, 'CN', 'PUBLIC_FUND', :tier, 'seed_gcrl_cn_public_fund_v1', 1)
        ON DUPLICATE KEY UPDATE
            institution_name = VALUES(institution_name),
            institution_short_name = VALUES(institution_short_name),
            country = VALUES(country),
            institution_type = VALUES(institution_type),
            tier = VALUES(tier),
            source = VALUES(source),
            is_active = VALUES(is_active)
        """
    )
    with engine.begin() as conn:
        conn.execute(sql, records)
    return len(records)


def load_institution_alias_map(engine) -> dict[str, str]:
    sql = text(
        """
        SELECT institution_id, institution_name, institution_short_name
        FROM cn_gcrl_institution_registry
        WHERE country = 'CN'
          AND institution_type = 'PUBLIC_FUND'
          AND is_active = 1
        """
    )
    mapping: dict[str, str] = {}
    with engine.connect() as conn:
        for inst_id, name, short in conn.execute(sql).fetchall():
            for raw in [name, short]:
                alias = str(raw or "").strip()
                if alias:
                    mapping[alias] = str(inst_id)
    return mapping


def _match_institution_id(management: object, alias_map: dict[str, str]) -> str | None:
    text_value = str(management or "").strip()
    if not text_value:
        return None
    if text_value in alias_map:
        return alias_map[text_value]
    for alias, inst_id in alias_map.items():
        if alias and (alias in text_value or text_value in alias):
            return inst_id
    return None


def fetch_fund_basic(pro) -> pd.DataFrame:
    frames: List[pd.DataFrame] = []
    for market in ["E", "O"]:
        df = pro.fund_basic(market=market, fields=FUND_BASIC_FIELDS)
        if df is not None and not df.empty:
            frames.append(df)
    if not frames:
        return pd.DataFrame(columns=FUND_BASIC_FIELDS.split(","))
    return pd.concat(frames, ignore_index=True).drop_duplicates(subset=["ts_code"], keep="first")


def normalize_fund_basic(raw: pd.DataFrame, alias_map: dict[str, str]) -> pd.DataFrame:
    if raw is None or raw.empty:
        return pd.DataFrame()
    out = raw.copy()
    for c in ["found_date", "due_date", "list_date", "issue_date", "delist_date", "purc_startdate", "redm_startdate"]:
        if c in out.columns:
            out[c] = _to_date_series(out[c])
    for c in ["issue_amount", "m_fee", "c_fee", "duration_year", "p_value", "min_amount", "exp_return"]:
        if c in out.columns:
            out[c] = pd.to_numeric(out[c], errors="coerce")
    out["institution_id"] = out["management"].apply(lambda x: _match_institution_id(x, alias_map))
    out = out[out["institution_id"].notna()].copy()
    out = out.rename(columns={"ts_code": "fund_code", "name": "fund_name"})
    cols = [
        "fund_code", "fund_name", "management", "custodian", "fund_type", "found_date", "due_date", "list_date",
        "issue_date", "delist_date", "issue_amount", "m_fee", "c_fee", "duration_year", "p_value", "min_amount",
        "exp_return", "benchmark", "status", "invest_type", "type", "trustee", "purc_startdate", "redm_startdate",
        "market", "institution_id",
    ]
    for c in cols:
        if c not in out.columns:
            out[c] = None
    return out[cols].drop_duplicates(subset=["fund_code"], keep="first")


def replace_fund_registry(engine, fund_df: pd.DataFrame) -> int:
    payload = _df_records(fund_df)
    if not payload:
        return 0
    cols = list(fund_df.columns)
    sql = text(
        f"""
        INSERT INTO cn_gcrl_fund_registry ({', '.join(cols)}, source)
        VALUES ({', '.join(':' + c for c in cols)}, :source)
        ON DUPLICATE KEY UPDATE
            {', '.join(f'{c}=VALUES({c})' for c in cols if c != 'fund_code')},
            source=VALUES(source)
        """
    )
    for r in payload:
        r["source"] = SOURCE_FUND_BASIC
    with engine.begin() as conn:
        for chunk in _chunked(payload, 1000):
            conn.execute(sql, list(chunk))
    return len(payload)


def fetch_fund_portfolio_period(pro, report_period: date, *, page_size: int, sleep_seconds: float) -> pd.DataFrame:
    frames: List[pd.DataFrame] = []
    period_str = report_period.strftime("%Y%m%d")
    offset = 0
    while True:
        try:
            df = pro.fund_portfolio(
                period=period_str,
                offset=offset,
                limit=page_size,
                fields=FUND_PORTFOLIO_FIELDS,
            )
        except Exception as exc:
            raise OptionalSourceUnavailable(str(exc)) from exc
        if df is None or df.empty:
            break
        frames.append(df)
        if len(df) < page_size:
            break
        offset += len(df)
        if sleep_seconds > 0:
            time.sleep(sleep_seconds)
    if not frames:
        return pd.DataFrame(columns=FUND_PORTFOLIO_FIELDS.split(","))
    return pd.concat(frames, ignore_index=True)


def normalize_position_snapshot(raw: pd.DataFrame, report_period: date, fund_registry: pd.DataFrame) -> pd.DataFrame:
    if raw is None or raw.empty:
        return pd.DataFrame()
    fund_map = fund_registry[["fund_code", "institution_id"]].drop_duplicates()
    out = raw.copy()
    out["report_period"] = report_period
    out["fund_code"] = out["ts_code"].astype(str).str.strip()
    out = out.merge(fund_map, on="fund_code", how="inner")
    out["stock_code"] = out["symbol"].astype(str).str.strip()
    out["symbol"] = out["stock_code"].str.split(".").str[0]
    out["ann_date"] = _to_date_series(out["ann_date"])
    for c in ["mkv", "amount", "stk_mkv_ratio", "stk_float_ratio"]:
        out[c] = pd.to_numeric(out[c], errors="coerce")
    out = out.rename(
        columns={
            "amount": "shares",
            "mkv": "market_value",
            "stk_mkv_ratio": "stock_mkv_ratio",
            "stk_float_ratio": "stock_float_ratio",
        }
    )
    out["stock_name"] = None
    cols = [
        "report_period", "fund_code", "institution_id", "stock_code", "symbol", "stock_name", "ann_date",
        "shares", "market_value", "stock_mkv_ratio", "stock_float_ratio",
    ]
    return out[cols].drop_duplicates(subset=["report_period", "fund_code", "stock_code"], keep="first")


def _eastmoney_url(fund_plain_code: str, report_period: date) -> str:
    # 天天基金 / 东方财富基金档案：基金持仓 type=jjcc；month is quarter-end month.
    return (
        "https://fundf10.eastmoney.com/FundArchivesDatas.aspx"
        f"?type=jjcc&code={fund_plain_code}&topline=10&year={report_period.year}&month={_report_month(report_period)}"
    )


def _extract_js_content(html_text: str) -> str:
    m = re.search(r'content\s*:\s*"(.*?)"\s*,\s*arryear', html_text, flags=re.S)
    if not m:
        m = re.search(r"content\s*:\s*'(.*?)'\s*,\s*arryear", html_text, flags=re.S)
    if not m:
        return ""
    content = m.group(1)
    content = content.replace(r'\"', '"').replace(r"\/", "/")
    content = content.replace(r"\n", "").replace(r"\t", "").replace(r"\r", "")
    return content


def _normalize_eastmoney_columns(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    out.columns = [str(c).replace("\n", "").replace(" ", "") for c in out.columns]
    return out


def _pick_col(cols: Sequence[str], candidates: Sequence[str]) -> str | None:
    for cand in candidates:
        for c in cols:
            if cand in str(c):
                return str(c)
    return None


def fetch_eastmoney_fund_holding_one(
    fund_code: str,
    report_period: date,
    *,
    session: requests.Session | None = None,
    timeout: float = 12.0,
) -> pd.DataFrame:
    plain = _fund_plain_code(fund_code)
    if not plain:
        return pd.DataFrame()
    sess = session or requests.Session()
    url = _eastmoney_url(plain, report_period)
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36",
        "Referer": f"https://fundf10.eastmoney.com/ccmx_{plain}.html",
    }
    resp = sess.get(url, headers=headers, timeout=timeout)
    resp.encoding = resp.apparent_encoding or "utf-8"
    resp.raise_for_status()
    content = _extract_js_content(resp.text)
    if not content or "暂无" in content:
        return pd.DataFrame()
    tables = pd.read_html(StringIO(content))
    if not tables:
        return pd.DataFrame()
    # Prefer table containing stock code/name/holding columns.
    table = None
    for t in tables:
        cols_text = "|".join(str(c) for c in t.columns)
        body_text = t.head(2).to_string()
        if "股票代码" in cols_text or "股票代码" in body_text:
            table = t
            break
    if table is None:
        table = tables[0]
    table = _normalize_eastmoney_columns(table)
    cols = list(table.columns)
    code_col = _pick_col(cols, ["股票代码", "代码"])
    name_col = _pick_col(cols, ["股票名称", "名称"])
    ratio_col = _pick_col(cols, ["占净值比例", "占基金净值比例", "比例"])
    shares_col = _pick_col(cols, ["持股数", "持有股数"])
    value_col = _pick_col(cols, ["持仓市值", "市值"])
    if not code_col:
        return pd.DataFrame()

    rows = []
    for _, row in table.iterrows():
        symbol = re.sub(r"\D", "", str(row.get(code_col, "")))
        if len(symbol) != 6:
            continue
        shares = _parse_cn_number(row.get(shares_col)) if shares_col else None
        market_value = _parse_cn_number(row.get(value_col)) if value_col else None
        ratio = _parse_cn_number(row.get(ratio_col)) if ratio_col else None
        # Eastmoney table normally uses 万股 / 万元, because header embeds units. If header contains 万 and parser did not see it,
        # multiply cell value by 10,000 to store base shares / yuan-like market_value unit consistently.
        if shares is not None and shares_col and "万" in shares_col and "万" not in str(row.get(shares_col, "")):
            shares *= 10000.0
        if market_value is not None and value_col and "万" in value_col and "万" not in str(row.get(value_col, "")):
            market_value *= 10000.0
        rows.append(
            {
                "report_period": report_period,
                "fund_code": fund_code,
                "stock_code": _stock_code_with_exchange(symbol),
                "symbol": symbol,
                "stock_name": str(row.get(name_col, "")).strip() if name_col else None,
                "ann_date": None,
                "shares": shares,
                "market_value": market_value,
                "stock_mkv_ratio": ratio,
                "stock_float_ratio": None,
            }
        )
    return pd.DataFrame(rows)


def fetch_eastmoney_fund_holdings(
    fund_registry: pd.DataFrame,
    report_period: date,
    *,
    max_funds: int = 0,
    sleep_seconds: float = 0.08,
    log=None,
) -> tuple[pd.DataFrame, dict]:
    if fund_registry is None or fund_registry.empty:
        return pd.DataFrame(), {"attempted_funds": 0, "success_funds": 0, "failed_funds": 0, "empty_funds": 0}
    df = fund_registry.copy()
    # First draft focuses on equity / hybrid public funds. Bond/MMF/QDII/FOF/REITs are not useful for A-share mainline migration.
    if "fund_type" in df.columns:
        mask = df["fund_type"].astype(str).str.contains("股票|混合", na=False)
        df = df[mask].copy()
    if max_funds and max_funds > 0:
        df = df.head(int(max_funds)).copy()

    sess = requests.Session()
    frames: list[pd.DataFrame] = []
    attempted = success = failed = empty = 0
    fund_inst = df[["fund_code", "institution_id"]].drop_duplicates()
    inst_map = dict(zip(fund_inst["fund_code"], fund_inst["institution_id"]))
    for fund_code in df["fund_code"].dropna().astype(str).drop_duplicates():
        attempted += 1
        try:
            one = fetch_eastmoney_fund_holding_one(fund_code, report_period, session=sess)
            if one is None or one.empty:
                empty += 1
            else:
                one["institution_id"] = inst_map.get(fund_code)
                frames.append(one)
                success += 1
        except Exception as exc:
            failed += 1
            if log is not None and failed <= 10:
                log.warning("[GCRL-CN] eastmoney holding failed fund=%s err=%s", fund_code, exc)
        if sleep_seconds > 0:
            time.sleep(sleep_seconds)
    if not frames:
        return pd.DataFrame(), {"attempted_funds": attempted, "success_funds": success, "failed_funds": failed, "empty_funds": empty}
    out = pd.concat(frames, ignore_index=True)
    cols = [
        "report_period", "fund_code", "institution_id", "stock_code", "symbol", "stock_name", "ann_date",
        "shares", "market_value", "stock_mkv_ratio", "stock_float_ratio",
    ]
    for c in cols:
        if c not in out.columns:
            out[c] = None
    out = out[out["institution_id"].notna()].copy()
    out = out[cols].drop_duplicates(subset=["report_period", "fund_code", "stock_code"], keep="first")
    return out, {"attempted_funds": attempted, "success_funds": success, "failed_funds": failed, "empty_funds": empty}


def replace_position_snapshot(engine, report_period: date, df: pd.DataFrame, *, source: str) -> int:
    with engine.begin() as conn:
        conn.execute(text("DELETE FROM cn_gcrl_position_snapshot WHERE report_period = :p"), {"p": report_period})
        payload = _df_records(df)
        if not payload:
            return 0
        cols = list(df.columns)
        sql = text(
            f"""
            INSERT INTO cn_gcrl_position_snapshot ({', '.join(cols)}, source)
            VALUES ({', '.join(':' + c for c in cols)}, :source)
            """
        )
        for r in payload:
            r["source"] = source
        for chunk in _chunked(payload, 1000):
            conn.execute(sql, list(chunk))
    return len(payload)


def build_and_replace_position_change(engine, report_period: date) -> int:
    prev_period = _prev_quarter_end(report_period)
    sql = text(
        """
        SELECT
            COALESCE(cur.report_period, :report_period) AS report_period,
            :prev_period AS prev_report_period,
            COALESCE(cur.fund_code, prev.fund_code) AS fund_code,
            COALESCE(cur.institution_id, prev.institution_id) AS institution_id,
            COALESCE(cur.stock_code, prev.stock_code) AS stock_code,
            COALESCE(cur.symbol, prev.symbol) AS symbol,
            COALESCE(cur.stock_name, prev.stock_name) AS stock_name,
            prev.shares AS prev_shares,
            cur.shares AS current_shares,
            prev.market_value AS prev_market_value,
            cur.market_value AS current_market_value
        FROM
            (SELECT * FROM cn_gcrl_position_snapshot WHERE report_period = :report_period) cur
        LEFT JOIN
            (SELECT * FROM cn_gcrl_position_snapshot WHERE report_period = :prev_period) prev
        ON cur.fund_code = prev.fund_code AND cur.stock_code = prev.stock_code
        UNION ALL
        SELECT
            :report_period AS report_period,
            :prev_period AS prev_report_period,
            prev.fund_code,
            prev.institution_id,
            prev.stock_code,
            prev.symbol,
            prev.stock_name,
            prev.shares AS prev_shares,
            NULL AS current_shares,
            prev.market_value AS prev_market_value,
            NULL AS current_market_value
        FROM
            (SELECT * FROM cn_gcrl_position_snapshot WHERE report_period = :prev_period) prev
        LEFT JOIN
            (SELECT * FROM cn_gcrl_position_snapshot WHERE report_period = :report_period) cur
        ON cur.fund_code = prev.fund_code AND cur.stock_code = prev.stock_code
        WHERE cur.fund_code IS NULL
        """
    )
    with engine.connect() as conn:
        rows = conn.execute(sql, {"report_period": report_period, "prev_period": prev_period}).fetchall()
    if not rows:
        with engine.begin() as conn:
            conn.execute(text("DELETE FROM cn_gcrl_position_change WHERE report_period = :p"), {"p": report_period})
        return 0
    df = pd.DataFrame(rows, columns=list(rows[0]._mapping.keys()))
    for c in ["prev_shares", "current_shares", "prev_market_value", "current_market_value"]:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    df["change_shares"] = df["current_shares"].fillna(0) - df["prev_shares"].fillna(0)
    df["market_value_change"] = df["current_market_value"].fillna(0) - df["prev_market_value"].fillna(0)

    def classify(row) -> str:
        prev = row["prev_shares"]
        cur = row["current_shares"]
        if pd.isna(prev) and not pd.isna(cur):
            return "NEW_POSITION"
        if not pd.isna(prev) and pd.isna(cur):
            return "EXIT_POSITION"
        if row["change_shares"] > 0:
            return "ADD_POSITION"
        if row["change_shares"] < 0:
            return "REDUCE_POSITION"
        return "UNCHANGED"

    df["change_type"] = df.apply(classify, axis=1)
    df["change_ratio_pct"] = None
    mask = df["prev_shares"].notna() & (df["prev_shares"] != 0)
    df.loc[mask, "change_ratio_pct"] = df.loc[mask, "change_shares"] / df.loc[mask, "prev_shares"] * 100.0
    cols = [
        "report_period", "prev_report_period", "fund_code", "institution_id", "stock_code", "symbol", "stock_name", "change_type",
        "prev_shares", "current_shares", "change_shares", "change_ratio_pct", "prev_market_value", "current_market_value", "market_value_change",
    ]
    payload = _df_records(df[cols])
    for r in payload:
        r["source"] = "derived_from_cn_gcrl_position_snapshot"
    with engine.begin() as conn:
        conn.execute(text("DELETE FROM cn_gcrl_position_change WHERE report_period = :p"), {"p": report_period})
        if not payload:
            return 0
        ins = text(
            f"""
            INSERT INTO cn_gcrl_position_change ({', '.join(cols)}, source)
            VALUES ({', '.join(':' + c for c in cols)}, :source)
            """
        )
        for chunk in _chunked(payload, 1000):
            conn.execute(ins, list(chunk))
    return len(payload)


def upsert_freshness(engine, dataset_name: str, report_period: date, source: str, status: str, row_count: int, message: str = "") -> None:
    sql = text(
        """
        INSERT INTO cn_gcrl_data_freshness (dataset_name, report_period, source, status, row_count, message)
        VALUES (:dataset_name, :report_period, :source, :status, :row_count, :message)
        ON DUPLICATE KEY UPDATE
            status = VALUES(status),
            row_count = VALUES(row_count),
            refreshed_at = CURRENT_TIMESTAMP,
            message = VALUES(message)
        """
    )
    with engine.begin() as conn:
        conn.execute(
            sql,
            {
                "dataset_name": dataset_name,
                "report_period": report_period,
                "source": source,
                "status": status,
                "row_count": int(row_count),
                "message": str(message or "")[:512],
            },
        )


def upsert_source_status(engine, source_name: str, source_type: str, status: str, message: str = "", row_count: int = 0) -> None:
    sql = text(
        """
        INSERT INTO cn_gcrl_data_source_status (source_name, source_type, status, message, row_count, last_success_time)
        VALUES (:source_name, :source_type, :status, :message, :row_count, IF(:status IN ('OK','SUCCESS','PARTIAL_OK'), CURRENT_TIMESTAMP, NULL))
        ON DUPLICATE KEY UPDATE
            source_type = VALUES(source_type),
            status = VALUES(status),
            message = VALUES(message),
            row_count = VALUES(row_count),
            last_check_time = CURRENT_TIMESTAMP,
            last_success_time = IF(:status IN ('OK','SUCCESS','PARTIAL_OK'), CURRENT_TIMESTAMP, last_success_time)
        """
    )
    with engine.begin() as conn:
        conn.execute(
            sql,
            {
                "source_name": source_name,
                "source_type": source_type,
                "status": status,
                "message": str(message or "")[:512],
                "row_count": int(row_count),
            },
        )


def _fetch_holdings_by_source(
    *,
    pro,
    fund_df: pd.DataFrame,
    report_period: date,
    holding_source: str,
    page_size: int,
    sleep_seconds: float,
    eastmoney_max_funds: int,
    eastmoney_sleep_seconds: float,
    log=None,
) -> tuple[pd.DataFrame, str, str, dict]:
    source = str(holding_source or "auto").strip().lower()
    if source == "none":
        return pd.DataFrame(), "none", "SKIPPED_BY_USER", {}
    if source in {"eastmoney", "auto"}:
        pos_df, stats = fetch_eastmoney_fund_holdings(
            fund_df,
            report_period,
            max_funds=eastmoney_max_funds,
            sleep_seconds=eastmoney_sleep_seconds,
            log=log,
        )
        if not pos_df.empty or source == "eastmoney":
            return pos_df, SOURCE_EASTMONEY_HOLDING, "OK" if not pos_df.empty else "EMPTY", stats
        if log is not None:
            log.warning("[GCRL-CN] eastmoney returned empty; try optional tushare fund_portfolio")
    if source in {"tushare", "auto"}:
        raw_pos = fetch_fund_portfolio_period(pro, report_period, page_size=page_size, sleep_seconds=sleep_seconds)
        pos_df = normalize_position_snapshot(raw_pos, report_period, fund_df)
        return pos_df, SOURCE_FUND_PORTFOLIO, "OK" if not pos_df.empty else "EMPTY", {"raw_position_rows": int(len(raw_pos))}
    raise ValueError(f"Unsupported holding_source={holding_source}; expected auto/eastmoney/tushare/none")


def run_gcrl_cn_public_fund_sync(
    *,
    engine,
    report_period: date,
    token: str,
    page_size: int = 5000,
    sleep_seconds: float = 0.2,
    holding_source: str = "eastmoney",
    eastmoney_max_funds: int = 0,
    eastmoney_sleep_seconds: float = 0.08,
    dry_run: bool = False,
    log=None,
) -> dict:
    ensure_tables(engine)
    seeded = seed_institution_registry(engine)
    alias_map = load_institution_alias_map(engine)
    patch_pandas_fillna_method_compat()
    pro = ts.pro_api(token)

    if log is not None:
        log.info("[GCRL-CN] fetch fund_basic")
    raw_fund = fetch_fund_basic(pro)
    fund_df = normalize_fund_basic(raw_fund, alias_map)
    if dry_run:
        return {
            "status": "DRY_RUN",
            "report_period": report_period.isoformat(),
            "seeded_institutions": seeded,
            "raw_fund_rows": int(len(raw_fund)),
            "matched_fund_rows": int(len(fund_df)),
            "holding_source": holding_source,
            "snapshot_rows": 0,
            "change_rows": 0,
        }

    fund_rows = replace_fund_registry(engine, fund_df)
    upsert_freshness(engine, "cn_gcrl_fund_registry", report_period, SOURCE_FUND_BASIC, "OK", fund_rows)
    upsert_source_status(engine, "TUSHARE_FUND_BASIC", "TUSHARE", "OK", row_count=fund_rows)

    if log is not None:
        log.info("[GCRL-CN] fetch holdings source=%s period=%s", holding_source, report_period)

    source_used = "none"
    holding_status = "SKIPPED"
    stats: dict = {}
    try:
        pos_df, source_used, holding_status, stats = _fetch_holdings_by_source(
            pro=pro,
            fund_df=fund_df,
            report_period=report_period,
            holding_source=holding_source,
            page_size=page_size,
            sleep_seconds=sleep_seconds,
            eastmoney_max_funds=eastmoney_max_funds,
            eastmoney_sleep_seconds=eastmoney_sleep_seconds,
            log=log,
        )
        snapshot_rows = replace_position_snapshot(engine, report_period, pos_df, source=source_used) if source_used != "none" else 0
        change_rows = build_and_replace_position_change(engine, report_period) if snapshot_rows > 0 else 0
        final_status = "OK" if snapshot_rows > 0 else ("PARTIAL_OK_NO_POSITION_ROWS" if source_used != "none" else "PARTIAL_OK_HOLDINGS_SKIPPED")
        upsert_freshness(engine, "cn_gcrl_position_snapshot", report_period, source_used, holding_status, snapshot_rows, str(stats))
        upsert_freshness(engine, "cn_gcrl_position_change", report_period, "derived_from_cn_gcrl_position_snapshot", "OK" if change_rows > 0 else "EMPTY", change_rows)
        upsert_source_status(engine, source_used.upper(), "HOLDING_SOURCE", holding_status, message=str(stats), row_count=snapshot_rows)
    except OptionalSourceUnavailable as exc:
        msg = str(exc)
        snapshot_rows = 0
        change_rows = 0
        final_status = "PARTIAL_OK_NO_FUND_PORTFOLIO_PERMISSION"
        source_used = SOURCE_FUND_PORTFOLIO
        upsert_freshness(engine, "cn_gcrl_position_snapshot", report_period, SOURCE_FUND_PORTFOLIO, "NO_PERMISSION", 0, msg)
        upsert_source_status(engine, "TUSHARE_FUND_PORTFOLIO", "TUSHARE", "NO_PERMISSION", message=msg, row_count=0)
    except Exception as exc:
        msg = str(exc)
        snapshot_rows = 0
        change_rows = 0
        final_status = "PARTIAL_OK_HOLDING_SOURCE_FAILED"
        upsert_freshness(engine, "cn_gcrl_position_snapshot", report_period, source_used, "FAILED", 0, msg)
        upsert_source_status(engine, str(source_used or "UNKNOWN").upper(), "HOLDING_SOURCE", "FAILED", message=msg, row_count=0)

    return {
        "status": final_status,
        "report_period": report_period.isoformat(),
        "seeded_institutions": seeded,
        "raw_fund_rows": int(len(raw_fund)),
        "matched_fund_rows": int(len(fund_df)),
        "fund_registry_rows": int(fund_rows),
        "holding_source_requested": holding_source,
        "holding_source_used": source_used,
        "holding_status": holding_status,
        "holding_stats": stats,
        "snapshot_rows": int(snapshot_rows),
        "change_rows": int(change_rows),
    }


def main(argv: List[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Sync CN GCRL public fund facts. Tushare for registry; EastMoney primary for holdings.")
    parser.add_argument("--report-period", required=True, help="Quarter end YYYYMMDD, e.g. 20250331")
    parser.add_argument("--token", default="", help="Tushare token; still required for fund_basic registry")
    parser.add_argument("--config", default="", help="Optional config file path")
    parser.add_argument("--page-size", type=int, default=5000)
    parser.add_argument("--sleep-seconds", type=float, default=0.2)
    parser.add_argument("--holding-source", default="eastmoney", choices=["eastmoney", "tushare", "auto", "none"], help="Holding source. Default eastmoney; tushare fund_portfolio is optional and may need permission.")
    parser.add_argument("--eastmoney-max-funds", type=int, default=0, help="Limit number of funds for holding crawl; 0 means all matched equity/hybrid funds.")
    parser.add_argument("--eastmoney-sleep-seconds", type=float, default=0.08)
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args(argv)

    token, tried_files = resolve_tushare_token(args.token, args.config)
    if not token:
        msg = "Tushare token is required for GCRL CN public fund registry sync"
        if tried_files:
            msg += f"; tried_files={', '.join(str(p) for p in tried_files)}"
        raise RuntimeError(msg)
    engine = build_engine()
    result = run_gcrl_cn_public_fund_sync(
        engine=engine,
        report_period=_to_report_period(args.report_period),
        token=token,
        page_size=max(1, int(args.page_size)),
        sleep_seconds=max(0.0, float(args.sleep_seconds)),
        holding_source=args.holding_source,
        eastmoney_max_funds=max(0, int(args.eastmoney_max_funds)),
        eastmoney_sleep_seconds=max(0.0, float(args.eastmoney_sleep_seconds)),
        dry_run=bool(args.dry_run),
    )
    print(result)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
