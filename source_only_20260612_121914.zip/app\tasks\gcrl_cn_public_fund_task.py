from __future__ import annotations

import os
from dataclasses import dataclass
from datetime import datetime

from app.tools.sync_cn_gcrl_public_fund_from_tushare import run_gcrl_cn_public_fund_sync
from app.tools.sync_cn_stock_daily_price_from_tushare import resolve_tushare_token


def _parse_yyyymmdd(s: str):
    return datetime.strptime(str(s), "%Y%m%d").date()


@dataclass
class GcrlCnPublicFundTask:
    name: str = "GcrlCnPublicFundTask"

    def run(self, ctx) -> None:
        report_period_raw = str(os.getenv("GCRL_CN_REPORT_PERIOD", ctx.config.end_date)).strip()
        token, tried_files = resolve_tushare_token("", "")
        if not token:
            msg = "Tushare token is required for GCRL CN public fund task"
            if tried_files:
                msg += f"; tried_files={', '.join(str(p) for p in tried_files)}"
            raise RuntimeError(msg)
        result = run_gcrl_cn_public_fund_sync(
            engine=ctx.engine,
            report_period=_parse_yyyymmdd(report_period_raw),
            token=token,
            page_size=max(1, int(os.getenv("GCRL_CN_PAGE_SIZE", "5000"))),
            sleep_seconds=max(0.0, float(os.getenv("GCRL_CN_SLEEP_SECONDS", "0.2"))),
            holding_source=str(os.getenv("GCRL_CN_HOLDING_SOURCE", "eastmoney")).strip().lower(),
            eastmoney_max_funds=max(0, int(os.getenv("GCRL_CN_EASTMONEY_MAX_FUNDS", "0"))),
            eastmoney_sleep_seconds=max(0.0, float(os.getenv("GCRL_CN_EASTMONEY_SLEEP_SECONDS", "0.08"))),
            dry_run=str(os.getenv("GCRL_CN_DRY_RUN", "0")).strip().lower() in {"1", "true", "yes", "on"},
            log=ctx.log,
        )
        ctx.log.info("[GCRL-CN] public fund sync result=%s", result)
