# Oracle vs MySQL Reconcile Report

- generated_at: `2026-02-25 13:18:28`
- run_id: `SR_BASE_V535_EP90_XP55_XC2_MH5_RF5_K2_COST5BPS`
- trade_date: `2026-02-25`

| metric | mysql | oracle | matched |
|---|---:|---:|:---:|
| ranked_rows | 525 | 0 | N |
| signal_rows | 525 | 0 | N |
| entry_snap_rows | 1 | 0 | N |
| holding_snap_rows | 1 | 0 | N |
| exit_snap_rows | 1 | 0 | N |
| bt_rows_upto_dt | 799 | 798 | N |
| bt_nav_last | 2.2590119315 | None | N |
| bt_nav_null_rows | 0 | 16 | N |

- mismatches: `8`
- mismatch_items:
  - `ranked_rows`: mysql=525, oracle=0
  - `signal_rows`: mysql=525, oracle=0
  - `entry_snap_rows`: mysql=1, oracle=0
  - `holding_snap_rows`: mysql=1, oracle=0
  - `exit_snap_rows`: mysql=1, oracle=0
  - `bt_rows_upto_dt`: mysql=799, oracle=798
  - `bt_nav_last`: mysql=2.2590119315, oracle=None
  - `bt_nav_null_rows`: mysql=0, oracle=16
