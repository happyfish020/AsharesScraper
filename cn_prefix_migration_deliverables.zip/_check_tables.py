"""Check cn_local_industry_master tables."""
import os
os.environ["ASHARE_MYSQL_USER"] = "cn_opr_red"
os.environ["ASHARE_MYSQL_PASSWORD"] = "sec_Bobo123"
os.environ["ASHARE_MYSQL_HOST"] = "localhost"
os.environ["ASHARE_MYSQL_PORT"] = "3306"
os.environ["ASHARE_MYSQL_DB"] = "cn_market_red"

from app.settings import build_engine
from sqlalchemy import text

e = build_engine()
with e.connect() as c:
    rs = c.execute(text("SELECT TABLE_NAME FROM information_schema.tables WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME LIKE '%cn_local_industry_master%'"))
    print("Tables matching cn_local_industry_master:")
    for r in rs:
        print(f"  {r[0]}")
    
    rs = c.execute(text("SELECT TABLE_NAME FROM information_schema.tables WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME LIKE '%cn_local_industry_map_hist%'"))
    print("\nTables matching cn_local_industry_map_hist:")
    for r in rs:
        print(f"  {r[0]}")
    
    rs = c.execute(text("SELECT TABLE_NAME FROM information_schema.tables WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME LIKE '%cn_local_industry_proxy%'"))
    print("\nTables matching cn_local_industry_proxy:")
    for r in rs:
        print(f"  {r[0]}")
